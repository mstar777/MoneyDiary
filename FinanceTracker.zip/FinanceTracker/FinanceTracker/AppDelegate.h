//
//  AppDelegate.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/1/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import <UIKit/UIKit.h>
@class User;
@class Transaction;
@class Wallet;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

extern AppDelegate *g_appDelegate;

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) User *currentUser;
@property (strong, nonatomic) Wallet *currentWallet;

+ (void)createCategory:(NSString *) walletId;
+ (void)showMessage:(NSString *)message;
- (void)setUserAccountInfo:(NSString *)userId;
- (void)removeUserAccountInfo;

@end

