//
//  AddCategoryVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/28/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// ================ this class is for create new category and add. works almost same as a edit category.
#import "AddCategoryVC.h"
#import "Constant.h"
#import "SelectCategoryVC.h"
#import "SelectWalletVC.h"
#import "WalletIconVC.h"

@interface AddCategoryVC () <SelectCategoryVCDelegate, SelectWalletVCDelegate, WalletIconVCDelegate>
{
    __weak IBOutlet UIImageView *catIconImgView;
    __weak IBOutlet UITextField *catNameTxtField;
    __weak IBOutlet UISegmentedControl *typeSegControl;
    __weak IBOutlet UIImageView *parentIconImg;
    __weak IBOutlet UILabel *parentNameLbl;
    __weak IBOutlet UIImageView *walletImgView;
    __weak IBOutlet UILabel *walletNameLbl;
    
    NSString* categoryIconName;
    Category* parentCategory;
    Wallet* currentWallet;
}
@end

@implementation AddCategoryVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupNavigationBar];
    // initialize and set category data.
    [typeSegControl setSelectedSegmentIndex:1];
    [self setCategoryIcon:@"category19.png"];
    [self setWallet:g_appDelegate.currentWallet];
    parentCategory = nil;
}

#pragma mark - Initialize
- (void) setupNavigationBar
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
                                              initWithTitle:@"Save"
                                              style:UIBarButtonItemStylePlain
                                              target:self
                                              action:@selector(addCategory)];
    [self.navigationItem.rightBarButtonItem setEnabled:NO];
    self.navigationItem.title = @"New Category";
}

- (void) addCategory // when click save button
{
    Category* newCategory = [Category MR_createEntity];
    newCategory.id = [[NSUUID UUID] UUIDString];
    newCategory.name = catNameTxtField.text;
    newCategory.image = categoryIconName;
    if (typeSegControl.selectedSegmentIndex == 0)
        newCategory.type = TYPE_INCOME;
    else if (typeSegControl.selectedSegmentIndex == 1)
        newCategory.type = TYPE_EXPENSE;
    if (parentCategory == nil)
        newCategory.parentid = @"";
    else
        newCategory.parentid = parentCategory.id;
    newCategory.walletid = currentWallet.id;
    
    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL success, NSError *error) {
        if (success) {
            NSLog(@"You successfully saved your context.");
            [self.navigationController popViewControllerAnimated:YES];
        } else if (error) {
            NSLog(@"Error saving context: %@", error.description);
        }
    }];
}

- (void) setCategoryIcon: (NSString *) iconName
{
    categoryIconName = iconName;
    [catIconImgView setImage:[UIImage imageNamed:iconName]];
}

- (void) setWallet: (Wallet *) wallet
{
    currentWallet = wallet;
    [walletImgView setImage:[UIImage imageNamed:wallet.image]];
    walletNameLbl.text = wallet.name;
}

- (void) setParentCategory: (Category *) parentCategory
{
    [parentIconImg setImage:[UIImage imageNamed:parentCategory.image]];
    parentNameLbl.text = parentCategory.name;
}

- (void) resetParentCategory
{
    parentCategory = nil;
    [parentIconImg setImage:[UIImage imageNamed:@"emptyCategory.png"]];
    parentNameLbl.text = @"Parent Category";
}

#pragma mark - Button Callbacks
- (IBAction)onClickCategoryIcon:(id)sender {
    WalletIconVC *walletVC = [self.storyboard instantiateViewControllerWithIdentifier:@"WalletIconVC"];
    walletVC.delegate = self;
    walletVC.prevVC = @"category";
    [self.navigationController pushViewController:walletVC animated:YES];
}

- (IBAction)categoryNameChanged:(id)sender {
    [self checkSave];
}

- (IBAction)onClickParentCategory:(id)sender {
    SelectCategoryVC *categoryVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SelectCategoryVC"];
    categoryVC.delegate = self;
    categoryVC.prevVC = @"AddCategoryVC";
    categoryVC.categoryType = typeSegControl.selectedSegmentIndex;
    [self.navigationController pushViewController:categoryVC animated:YES];
}

- (IBAction)onClickChangeWallet:(id)sender {
    SelectWalletVC *walletVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SelectWalletVC"];
    walletVC.delegate = self;
    [self.navigationController pushViewController:walletVC animated:YES];
}
- (IBAction)typeSegChanged:(id)sender {
    if (parentCategory != nil) {
        UISegmentedControl *segment=(UISegmentedControl*)sender;
        if (parentCategory.type == TYPE_INCOME && segment.selectedSegmentIndex == 1) {
            [self resetParentCategory];
        }
        else if (parentCategory.type == TYPE_EXPENSE && segment.selectedSegmentIndex == 0)
            [self resetParentCategory];
    }
}

#pragma mark - Delegation Methods for VC
- (void) categoryUpdated:(Category *)category
{
    parentCategory = category;
    [self setParentCategory:category];
    [self checkSave];
}

- (void) walletUpdated:(Wallet *)wallet
{
    [self setWallet:wallet];
    [self checkSave];
}

- (void) iconUpdated:(NSString *)iconName {
    [self setCategoryIcon:iconName];
    [self checkSave];
}

- (void) checkSave
{
    if ([catNameTxtField.text length] > 0) {
        [self.navigationItem.rightBarButtonItem setEnabled:YES];
    }
    else
        [self.navigationItem.rightBarButtonItem setEnabled:NO];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
