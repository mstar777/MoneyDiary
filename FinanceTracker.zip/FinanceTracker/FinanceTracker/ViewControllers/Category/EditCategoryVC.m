//
//  EditCategoryVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/28/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// ============== this is for edit a category. works almost same as a add category vc ===================
#import "EditCategoryVC.h"
#import "Constant.h"
#import "SelectWalletVC.h"
#import "EditOneCategoryVC.h"

@interface EditCategoryVC () <SelectWalletVCDelegate>
{
    __weak IBOutlet UIImageView *walletImgView;
    __weak IBOutlet UILabel *walletNameLbl;
    __weak IBOutlet UITableView *categoryTableView;
    
    Wallet* currentWallet;
    NSMutableArray* categoryInArray;
    NSMutableArray* categoryExpArray;
    NSMutableArray* categoryArray;
}
@end

@implementation EditCategoryVC

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self fetchData];
    [categoryTableView reloadData];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupNavigationBar];
    [self setWallet:g_appDelegate.currentWallet];
}

- (void) setupNavigationBar
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
                                              initWithTitle:@"Add"
                                              style:UIBarButtonItemStylePlain
                                              target:self
                                              action:@selector(addCategory)];
    //[self.navigationItem.rightBarButtonItem setEnabled:NO];
    self.navigationItem.title = @"Categories";
}

- (void) fetchData
{
    categoryArray = [[NSMutableArray alloc] init];
    categoryInArray = [[NSMutableArray alloc] init];
    categoryExpArray = [[NSMutableArray alloc] init];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"walletid ==[c] %@ AND parentid ==[c] %@", currentWallet.id, @""];
    NSMutableArray* categories  = [[Category MR_findAllSortedBy:@"name" ascending:YES withPredicate:predicate] mutableCopy];
    
    for (int i = 0; i < categories.count; i++) {
        Category* categoryToCheck = [categories objectAtIndex:i];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"walletid ==[c] %@ AND parentid ==[c] %@", currentWallet.id, categoryToCheck.id];
        NSArray* subCategories  = [Category MR_findAllWithPredicate:predicate];
        if (subCategories.count > 0) {
            NSIndexSet* indexes = [NSIndexSet indexSetWithIndexesInRange:NSMakeRange(i+1, subCategories.count)];
            [categories insertObjects:subCategories atIndexes:indexes];
            i += subCategories.count;
        }
    }
    for (int i = 0; i < categories.count; i++) {
        Category* catToAdd = [categories objectAtIndex:i];
        if (catToAdd.type == TYPE_EXPENSE) {
            [categoryExpArray addObject:catToAdd];
        }
        else if (catToAdd.type == TYPE_INCOME)
            [categoryInArray addObject:catToAdd];
        else
            [categoryInArray addObject:catToAdd];
    }
    [categoryArray addObject:categoryExpArray];
    [categoryArray addObject:categoryInArray];
}

- (void) addCategory
{
    UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"AddCategoryVC"];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void) setWallet: (Wallet *) wallet
{
    currentWallet = wallet;
    [walletImgView setImage:[UIImage imageNamed:wallet.image]];
    walletNameLbl.text = wallet.name;
}

- (void) walletUpdated:(Wallet *)wallet
{
    [self setWallet:wallet];
    [self fetchData];
    [categoryTableView reloadData];
}
- (IBAction)onClickWallet:(id)sender {
    SelectWalletVC *walletVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SelectWalletVC"];
    walletVC.delegate = self;
    [self.navigationController pushViewController:walletVC animated:YES];
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)theTableView
{
    return categoryArray.count;
}

- (NSInteger)tableView:(UITableView *)theTableView numberOfRowsInSection:(NSInteger)section
{
    NSMutableArray* array = [categoryArray objectAtIndex:section];
    return [array count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 50;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 30)];
    // 4 * 69 (width of label) + 3 * 8 (distance between labels) = 300
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 4, 150, 22)];
    if (section == 0)
        label.text = @"EXPENSES";
    else if (section == 1)
        label.text = @"INCOME";
    label.font=[label.font fontWithSize:12];
    
    [headerView addSubview:label];
    return headerView;
}

// the cell will be returned to the tableView
- (UITableViewCell* )tableView:(UITableView* )theTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableArray* array = [categoryArray objectAtIndex:indexPath.section];
    Category* category = [array objectAtIndex:indexPath.row];
    
    NSString *cellIdentifier = @"categorycell";
    if (![category.parentid isEqualToString:@""]) {
        cellIdentifier = @"categorysubcell";
    }
    UITableViewCell *cell = [theTableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    UIImageView* categoryIconImage = [cell viewWithTag:10];
    [categoryIconImage setImage:[UIImage imageNamed:category.image]];
    UILabel* categoryNameLbl = [cell viewWithTag:20];
    categoryNameLbl.text = category.name;
    
    if (![category.parentid isEqualToString:@""]) {
        BOOL bIsLastCategory = NO;
        Category* nextCategory;
        if (theTableView.tag == 100)
        {
            if (indexPath.row < categoryInArray.count - 1){
                nextCategory = [categoryInArray objectAtIndex:indexPath.row + 1];
                if ([nextCategory.parentid isEqualToString:@""])
                    bIsLastCategory = YES;
            }
            else
                bIsLastCategory = YES;
        }
        else
        {
            if (indexPath.row < categoryExpArray.count - 1){
                nextCategory = [categoryExpArray objectAtIndex:indexPath.row + 1];
                if ([nextCategory.parentid isEqualToString:@""])
                    bIsLastCategory = YES;
            }
            else
                bIsLastCategory = YES;
        }
        UIImageView* dotImage = [cell viewWithTag:5];
        if (bIsLastCategory == YES) {
            //UIImageView* dotImage = [cell viewWithTag:5];
            [dotImage setImage:[UIImage imageNamed:@"dotline_last.png"]];
        }
        else
            [dotImage setImage:[UIImage imageNamed:@"dotline.png"]];
    }
    return cell;
}

#pragma mark - UITableViewDelegate
// when user tap the row, what action you want to perform
- (void)tableView:(UITableView* )theTableView didSelectRowAtIndexPath:(NSIndexPath* )indexPath
{
    NSMutableArray* array = [categoryArray objectAtIndex:indexPath.section];
    Category* category = [array objectAtIndex:indexPath.row];
    
    EditOneCategoryVC *editCatVC = [self.storyboard instantiateViewControllerWithIdentifier:@"EditOneCategoryVC"];
    editCatVC.categoryToEdit = category;
    [self.navigationController pushViewController:editCatVC animated:YES];
    /*
    if (theTableView.tag == 100) {
        Category* category = [categoryInArray objectAtIndex:indexPath.row];
        if(self.delegate) {
            [self.delegate categoryUpdated:category];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
    else if (theTableView.tag == 200)
    {
        Category* category = [categoryExpArray objectAtIndex:indexPath.row];
        if(self.delegate) {
            [self.delegate categoryUpdated:category];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
    
    
    NSLog(@"selected %ld row", (long)indexPath.row);*/
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
