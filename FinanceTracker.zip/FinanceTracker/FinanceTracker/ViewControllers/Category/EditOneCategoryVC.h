//
//  EditOneCategoryVC.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/29/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constant.h"

@interface EditOneCategoryVC : UIViewController

@property (strong, nonatomic) Category* categoryToEdit;

@end
