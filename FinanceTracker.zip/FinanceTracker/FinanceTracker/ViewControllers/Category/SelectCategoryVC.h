//
//  SelectCategoryVC.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/22/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constant.h"

@protocol SelectCategoryVCDelegate
- (void) categoryUpdated:(Category *)category;
@end

@interface SelectCategoryVC : UIViewController
@property (strong, nonatomic) id<SelectCategoryVCDelegate> delegate;
@property (strong, nonatomic) NSString* prevVC;
@property (assign, nonatomic) NSInteger categoryType;
@property (strong, nonatomic) Wallet* walletForCategory;
@end
