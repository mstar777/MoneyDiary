//
//  EditOneCategoryVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/29/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import "EditOneCategoryVC.h"
#import "SelectCategoryVC.h"
#import "SelectWalletVC.h"
#import "WalletIconVC.h"

@interface EditOneCategoryVC () <SelectCategoryVCDelegate, SelectWalletVCDelegate, WalletIconVCDelegate>
{
    __weak IBOutlet UIImageView *catIconImgView;
    __weak IBOutlet UITextField *catNameTxtField;
    __weak IBOutlet UISegmentedControl *typeSegControl;
    __weak IBOutlet UIImageView *parentIconImg;
    __weak IBOutlet UILabel *parentNameLbl;
    __weak IBOutlet UIImageView *walletImgView;
    __weak IBOutlet UILabel *walletNameLbl;
    
    NSString* categoryIconName;
    Category* parentCategory;
    Wallet* currentWallet;
}
@end

@implementation EditOneCategoryVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupNavigationBar];
    [self setData];
    
}

#pragma mark - Initialize
- (void) setData
{
    [self setCategoryIcon:self.categoryToEdit.image];
    catNameTxtField.text = self.categoryToEdit.name;
    Wallet* wallet = [Wallet MR_findFirstByAttribute:@"id" withValue:self.categoryToEdit.walletid];
    [self setWallet:wallet];
    Category* parentCat = [Category MR_findFirstByAttribute:@"id" withValue:self.categoryToEdit.parentid];
    if (parentCat != nil)
        [self setParentCategory:parentCat];
    else
        [self resetParentCategory];
    if (self.categoryToEdit.type == TYPE_EXPENSE)
        [typeSegControl setSelectedSegmentIndex: 1];
    else if (self.categoryToEdit.type == TYPE_INCOME)
        [typeSegControl setSelectedSegmentIndex:0];
    
}

- (void) setupNavigationBar
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
                                              initWithTitle:@"Save"
                                              style:UIBarButtonItemStylePlain
                                              target:self
                                              action:@selector(addCategory)];
    [self.navigationItem.rightBarButtonItem setEnabled:NO];
    self.navigationItem.title = @"Edit Category";
}

- (void) addCategory
{
    //Category* newCategory = [Category MR_createEntity];
    //newCategory.id = [[NSUUID UUID] UUIDString];
    self.categoryToEdit.name = catNameTxtField.text;
    self.categoryToEdit.image = categoryIconName;
    if (typeSegControl.selectedSegmentIndex == 0)
        self.categoryToEdit.type = TYPE_INCOME;
    else if (typeSegControl.selectedSegmentIndex == 1)
        self.categoryToEdit.type = TYPE_EXPENSE;
    if (parentCategory == nil)
        self.categoryToEdit.parentid = @"";
    else
        self.categoryToEdit.parentid = parentCategory.id;
    self.categoryToEdit.walletid = currentWallet.id;
    
    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL success, NSError *error) {
        if (success) {
            NSLog(@"You successfully saved your context.");
            [self.navigationController popViewControllerAnimated:YES];
        } else if (error) {
            NSLog(@"Error saving context: %@", error.description);
        }
    }];
}

- (void) setCategoryIcon: (NSString *) iconName
{
    categoryIconName = iconName;
    [catIconImgView setImage:[UIImage imageNamed:iconName]];
}

- (void) setWallet: (Wallet *) wallet
{
    currentWallet = wallet;
    [walletImgView setImage:[UIImage imageNamed:wallet.image]];
    walletNameLbl.text = wallet.name;
    //[self checkSave];
}

- (void) setParentCategory: (Category *) category
{
    parentCategory = category;
    [parentIconImg setImage:[UIImage imageNamed:category.image]];
    parentNameLbl.text = category.name;
    //[self checkSave];
}

- (void) resetParentCategory
{
    parentCategory = nil;
    [parentIconImg setImage:[UIImage imageNamed:@"emptyCategory.png"]];
    parentNameLbl.text = @"Parent Category";
}

#pragma mark - Button Callbacks
- (IBAction)onClickCategoryIcon:(id)sender {
    WalletIconVC *walletVC = [self.storyboard instantiateViewControllerWithIdentifier:@"WalletIconVC"];
    walletVC.delegate = self;
    walletVC.prevVC = @"category";
    [self.navigationController pushViewController:walletVC animated:YES];
}

- (IBAction)categoryNameChanged:(id)sender {
    [self checkSave];
}

- (IBAction)onClickParentCategory:(id)sender {
    SelectCategoryVC *categoryVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SelectCategoryVC"];
    categoryVC.delegate = self;
    categoryVC.prevVC = @"AddCategoryVC";
    categoryVC.categoryType = typeSegControl.selectedSegmentIndex;
    [self.navigationController pushViewController:categoryVC animated:YES];
}

- (IBAction)onClickChangeWallet:(id)sender {
    SelectWalletVC *walletVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SelectWalletVC"];
    walletVC.delegate = self;
    [self.navigationController pushViewController:walletVC animated:YES];
}

- (IBAction)typeSegChanged:(id)sender {
    if (parentCategory != nil) {
        UISegmentedControl *segment=(UISegmentedControl*)sender;
        if (parentCategory.type == TYPE_INCOME && segment.selectedSegmentIndex == 1) {
            [self resetParentCategory];
        }
        else if (parentCategory.type == TYPE_EXPENSE && segment.selectedSegmentIndex == 0)
            [self resetParentCategory];
    }
    [self checkSave];
}

- (IBAction)onClickDelete:(id)sender {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warning"
                                                    message:@"Are you sure you want to delete this category? All the transactions of this category would be deleted too."
                                                   delegate:self
                                          cancelButtonTitle:@"Confirm"
                                          otherButtonTitles:@"Cancel", nil];
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    // the user clicked OK
    if (buttonIndex == 0) {
        // do something here...
        [self.categoryToEdit MR_deleteEntity];
        [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL success, NSError *error) {
            if (success) {
                NSLog(@"You successfully saved your context.");
                [self.navigationController popViewControllerAnimated:YES];
            } else if (error) {
                NSLog(@"Error saving context: %@", error.description);
            }
        }];
    }
}

#pragma mark - Delegation Methods for VC
- (void) categoryUpdated:(Category *)category
{
    //parentCategory = category;
    [self setParentCategory:category];
    [self checkSave];
}

- (void) walletUpdated:(Wallet *)wallet
{
    [self setWallet:wallet];
    [self checkSave];
}

- (void) iconUpdated:(NSString *)iconName {
    [self setCategoryIcon:iconName];
    [self checkSave];
}

- (void) checkSave
{
    NSInteger type = self.categoryToEdit.type == TYPE_EXPENSE ? 1 : 0;
    Category* parentCat = [Category MR_findFirstByAttribute:@"id" withValue:self.categoryToEdit.parentid];
    if ([catNameTxtField.text length] > 0 &&
        (![categoryIconName isEqualToString:self.categoryToEdit.image] ||
         ![catNameTxtField.text isEqualToString:self.categoryToEdit.name] ||
         type != typeSegControl.selectedSegmentIndex ||
         (/*parentCategory != nil && */![parentCategory.id isEqualToString:self.categoryToEdit.parentid]) ||
         //![parentCategory isEqual:parentCat] ||
         ![currentWallet.id isEqualToString:self.categoryToEdit.walletid])) {
        [self.navigationItem.rightBarButtonItem setEnabled:YES];
    }
    else
        [self.navigationItem.rightBarButtonItem setEnabled:NO];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
