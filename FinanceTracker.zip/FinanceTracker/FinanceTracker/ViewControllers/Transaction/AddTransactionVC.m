//
//  AddTransactionVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/21/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// ============= This class is for adding one transaction
#import "AddTransactionVC.h"
#import "Constant.h"
#import "SelectCategoryVC.h"
#import "AddNoteVC.h"
#import "SelectWalletVC.h"
#import "PDTSimpleCalendarViewController.h"
#import "PDTSimpleCalendarViewCell.h"
#import "PDTSimpleCalendarViewHeader.h"

@interface AddTransactionVC () <SelectCategoryVCDelegate, AddNoteVCDelegate, SelectWalletVCDelegate, PDTSimpleCalendarViewDelegate>
{
    __weak IBOutlet UILabel *currencySymbolLbl;
    __weak IBOutlet UITextField *amountTxtField;
    __weak IBOutlet UIImageView *categoryImgView;
    __weak IBOutlet UILabel *categoryName;
    __weak IBOutlet UILabel *notesLbl;
    __weak IBOutlet UIImageView *walletImgView;
    __weak IBOutlet UILabel *dateLbl;
    __weak IBOutlet UILabel *walletNameLbl;
    __weak IBOutlet UILabel *eventLbl;
    
    PDTSimpleCalendarViewController *calendarViewController;
    NSString* notesAdd;
    Category* categoryAdd;
    NSDate* dateAdd;
    Wallet* walletAdd;
}
@end

@implementation AddTransactionVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupNavigationBar];
    [self initCalendar];
    
    [self setWallet:g_appDelegate.currentWallet];
    [self setDate:[NSDate date]];
    notesAdd = @"";
    categoryAdd = nil;
}

#pragma mark - Initialize
- (void) setupNavigationBar
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
                                              initWithTitle:@"Save"
                                              style:UIBarButtonItemStylePlain
                                              target:self
                                              action:@selector(addTransaction)];
    [self.navigationItem.rightBarButtonItem setEnabled:NO];
    self.navigationItem.title = @"Add Transaction";
}

- (void) addTransaction // called when click save button
{
    // create a transaction from inputed info.
    Transaction* transaction = [Transaction MR_createEntity];
    transaction.amount = [amountTxtField.text floatValue];
    transaction.date = dateAdd;
    transaction.notes = notesAdd;
    transaction.category = categoryAdd;
    transaction.walletid = walletAdd.id;
    if (categoryAdd.type == TYPE_EXPENSE)
        transaction.amount = transaction.amount * -1;
    g_appDelegate.currentWallet.balance += transaction.amount;
    
    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL success, NSError *error) {
        if (success) {
            NSLog(@"You successfully saved your context.");
            [self.navigationController popViewControllerAnimated:YES];
        } else if (error) {
            NSLog(@"Error saving context: %@", error.description);
        }
    }];
}

- (void) initCalendar
{
    calendarViewController = [[PDTSimpleCalendarViewController alloc] init];
    //This is the default behavior, will display a full year starting the first of the current month
    [calendarViewController setDelegate:self];
    calendarViewController.weekdayHeaderEnabled = YES;
    calendarViewController.weekdayTextType = PDTSimpleCalendarViewWeekdayTextTypeShort;
    NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
    offsetComponents.month = -5;
    NSDate *lastDate =[calendarViewController.calendar dateByAddingComponents:offsetComponents toDate:[NSDate date] options:0];
    calendarViewController.firstDate = lastDate;
    [calendarViewController setSelectedDate:[NSDate date]];
    //[calendarViewController scrollToDate:[NSDate date] animated:NO];
    [calendarViewController scrollToSelectedDate:NO];
    [[PDTSimpleCalendarViewCell appearance] setCircleSelectedColor:[UIColor grayColor]];
    
    [calendarViewController setTitle:@"Pick Date"];
    if ([UIViewController instancesRespondToSelector:@selector(edgesForExtendedLayout)]) {
        [calendarViewController setEdgesForExtendedLayout:UIRectEdgeNone];
    }
}

- (void) setDate: (NSDate*) date
{
    dateAdd = date;
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"dd"];
    NSString* day = [df stringFromDate:date];
    [df setDateFormat:@"MMMM"];
    NSString* month = [df stringFromDate:date];
    [df setDateFormat:@"yyyy"];
    NSString* year = [df stringFromDate:date];
    
    NSInteger weekday = [[NSCalendar currentCalendar] component:NSCalendarUnitWeekday
                                                                     fromDate:date];
    
    dateLbl.text = [NSString stringWithFormat:@"%@ %@ %@ %@", [self stringFromWeekDay:weekday], day, month, year];
}

- (void) setWallet: (Wallet *) wallet
{
    walletAdd = wallet;
    [walletImgView setImage:[UIImage imageNamed:wallet.image]];
    walletNameLbl.text = wallet.name;
    currencySymbolLbl.text = wallet.currency.symbol;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Button Callbacks
- (IBAction)onClickSelectCategory:(id)sender {
    SelectCategoryVC *categoryVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SelectCategoryVC"];
    categoryVC.delegate = self;
    [self.navigationController pushViewController:categoryVC animated:YES];
}

- (IBAction)onClickNote:(id)sender {
    AddNoteVC *addNoteVC = [self.storyboard instantiateViewControllerWithIdentifier:@"AddNoteVC"];
    addNoteVC.delegate = self;
    addNoteVC.noteToEdit = notesAdd;
    [self.navigationController pushViewController:addNoteVC animated:YES];
}

- (IBAction)onClickDate:(id)sender {
    [self.navigationController pushViewController:calendarViewController animated:YES];
}

- (IBAction)onClickWallet:(id)sender {
    SelectWalletVC *walletVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SelectWalletVC"];
    walletVC.delegate = self;
    [self.navigationController pushViewController:walletVC animated:YES];
}

#pragma mark - Delegation Methods for VC
- (void) categoryUpdated:(Category *)category // called after select category
{
    categoryAdd = category;
    [categoryImgView setImage:[UIImage imageNamed:category.image]];
    categoryName.text = category.name;
    [self checkSave];
}

- (void) noteUpdated:(NSString *)notes // called after press back button in add note screen
{
    notesAdd = notes;
    if ([notesAdd isEqualToString:@""])
        notesLbl.text = @"Note";
    else
        notesLbl.text = notes;
    [self checkSave];
    /*
    if (![notes isEqualToString:@""]){
        notesLbl.text = notes;
        notesAdd = notes;
    }
    
    [self checkSave];*/
}

- (void) walletUpdated:(Wallet *)wallet // called after select wallet
{
    [self setWallet:wallet];
}

- (IBAction)textFieldChanged:(UITextField *)sender {
    [self checkSave];
}

- (IBAction)textFieldEnded:(UITextField *)sender {
    NSNumberFormatter* nf = [[NSNumberFormatter alloc] init];
    nf.positiveFormat = @"0.##";
    amountTxtField.text = [NSString stringWithFormat:@"%@", [nf stringFromNumber: [NSNumber numberWithFloat: [amountTxtField.text floatValue]]]];
}

#pragma mark - PDTSimpleCalendarViewDelegate

- (void)simpleCalendarViewController:(PDTSimpleCalendarViewController *)controller didSelectDate:(NSDate *)date
{
    [self setDate:date];
    [self checkSave];
    //[self.navigationController popToViewController:controller animated:YES];
    //NSLog(@"Date Selected : %@",date);
    //NSLog(@"Date Selected with Locale %@", [date descriptionWithLocale:[NSLocale systemLocale]]);
}

- (UIColor *)simpleCalendarViewController:(PDTSimpleCalendarViewController *)controller circleColorForDate:(NSDate *)date
{
    return [UIColor whiteColor];
}

- (UIColor *)simpleCalendarViewController:(PDTSimpleCalendarViewController *)controller textColorForDate:(NSDate *)date
{
    return [UIColor orangeColor];
}

- (void) checkSave // check if transaction can be added.
{
    float fAmount = [amountTxtField.text floatValue];
    if (fAmount > 0.f && categoryAdd != nil) {
        [self.navigationItem.rightBarButtonItem setEnabled:YES];
    }
    else{
        [self.navigationItem.rightBarButtonItem setEnabled:NO];
    }
}

- (NSString *) stringFromWeekDay:(NSInteger) weekDay
{
    switch (weekDay)
    {
        case 1:
            return @"Sunday";
            break;
        case 2:
            return @"Monday";
            break;
        case 3:
            return @"Tuesday";
            break;
        case 4:
            return @"Wednesday";
            break;
        case 5:
            return @"Thursday";
            break;
        case 6:
            return @"Friday";
            break;
        case 7:
            return @"Saturday";
            break;
        default:
            return @"Sunday";
            break;
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
