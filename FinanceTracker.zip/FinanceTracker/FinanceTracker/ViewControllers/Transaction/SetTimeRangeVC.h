//
//  SetTimeRangeVC.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 4/2/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SetTimeRangeVCDelegate
- (void) timeRangeUpdated:(NSDate *)startDate endDate:(NSDate *) endDate;
@end

@interface SetTimeRangeVC : UIViewController
@property (strong, nonatomic) id<SetTimeRangeVCDelegate> delegate;
@end
