//
//  AdjustBalanceVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 4/5/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// ================== this class is for adjust balance =================
#import "AdjustBalanceVC.h"
#import "Constant.h"
#import "SelectWalletVC.h"

@interface AdjustBalanceVC () <SelectWalletVCDelegate>
{
    __weak IBOutlet UIImageView *walletIconImg;
    __weak IBOutlet UILabel *walletNameLbl;
    __weak IBOutlet UITextField *amountTxtField;
    Wallet* walletForBalance;
}
@end

@implementation AdjustBalanceVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setupNavigationBar];
    [self setWallet:g_appDelegate.currentWallet];
}

#pragma mark - Initialize
- (void) setupNavigationBar
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
                                              initWithTitle:@"Save"
                                              style:UIBarButtonItemStylePlain
                                              target:self
                                              action:@selector(saveBalance)];
    [self.navigationItem.rightBarButtonItem setEnabled:NO];
    self.navigationItem.title = @"Adjust Balance";
}

- (void) saveBalance // called when press save button
{
    walletForBalance.balance = [amountTxtField.text floatValue];
    
    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL success, NSError *error) {
        if (success) {
            NSLog(@"You successfully saved your context.");
            [self.navigationController popViewControllerAnimated:YES];
        } else if (error) {
            NSLog(@"Error saving context: %@", error.description);
        }
    }];
}

- (void) setWallet: (Wallet *) wallet // set selected wallet from selectwalletvc
{
    walletForBalance = wallet;
    [walletIconImg setImage:[UIImage imageNamed:wallet.image]];
    walletNameLbl.text = wallet.name;
    
    NSNumberFormatter* nf = [[NSNumberFormatter alloc] init];
    nf.positiveFormat = @"0.##";
    amountTxtField.text = [NSString stringWithFormat:@"%@", [nf stringFromNumber: [NSNumber numberWithFloat: fabs(walletForBalance.balance)]]];
}

#pragma mark - Button Callbacks

- (IBAction)onClickWallet:(id)sender { // called when click wallet
    SelectWalletVC *walletVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SelectWalletVC"];
    walletVC.delegate = self;
    [self.navigationController pushViewController:walletVC animated:YES];
}

#pragma mark - Delegation Methods for VC
- (void)walletUpdated:(Wallet *)wallet // called after select a wallet from selectwallet vc
{
    [self setWallet:wallet];
    [self checkSave];
}

- (IBAction)textFieldChanged:(UITextField *)sender { // called while typing money amount
    [self checkSave];
}

- (IBAction)textFieldEnded:(UITextField *)sender { // called when user typing ended
    NSNumberFormatter* nf = [[NSNumberFormatter alloc] init];
    nf.positiveFormat = @"0.##";
    amountTxtField.text = [NSString stringWithFormat:@"%@", [nf stringFromNumber: [NSNumber numberWithFloat: [amountTxtField.text floatValue]]]];
}

- (void) checkSave // check if save can be enabled
{
    float fAmount = [amountTxtField.text floatValue];
    if (fAmount > 0.f && walletForBalance != nil && (fAmount != fabs(walletForBalance.balance) ||
                                                     ![g_appDelegate.currentWallet.id isEqualToString:walletForBalance.id])) {
        [self.navigationItem.rightBarButtonItem setEnabled:YES];
    }
    else{
        [self.navigationItem.rightBarButtonItem setEnabled:NO];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
