//
//  AddRecurringTransVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 4/5/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import "AddRecurringTransVC.h"
#import "Constant.h"
#import "RepeatOptionTVC.h"
#import "SelectCategoryVC.h"
#import "AddNoteVC.h"
#import "SelectWalletVC.h"

@interface AddRecurringTransVC () <RepeatOptionTVCDelegate, SelectCategoryVCDelegate, AddNoteVCDelegate, SelectWalletVCDelegate>
{
    __weak IBOutlet UILabel     *currencySymbolLbl;
    __weak IBOutlet UITextField *amountTxtField;
    __weak IBOutlet UIImageView *categoryImgView;
    __weak IBOutlet UILabel     *categoryName;
    __weak IBOutlet UILabel     *notesLbl;
    __weak IBOutlet UIImageView *walletImgView;
    __weak IBOutlet UILabel     *walletNameLbl;
    __weak IBOutlet UILabel     *eventLbl;
    __weak IBOutlet UILabel *repeatOptionLbl;
    __weak IBOutlet UILabel *statusLbl;
    __weak IBOutlet UISwitch *statusSwitch;
    
    NSString*   notesAdd;
    Category*   categoryAdd;
    Wallet*     walletAdd;
    NSInteger   frequencyAdd;
    NSInteger   intervalAdd;
    NSDate*     startDateAdd;
}
@end

@implementation AddRecurringTransVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupNavigationBar];
    
    [self setWallet:g_appDelegate.currentWallet];
    notesAdd = @"";
    categoryAdd = nil;
    frequencyAdd = 0;
    intervalAdd = 0;
    startDateAdd = [NSDate date];
    [self setRepeatOption];
}

#pragma mark - Initialize
- (void) setupNavigationBar
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
                                              initWithTitle:@"Save"
                                              style:UIBarButtonItemStylePlain
                                              target:self
                                              action:@selector(addTransaction)];
    [self.navigationItem.rightBarButtonItem setEnabled:NO];
    self.navigationItem.title = @"Add Recurring Transaction";
}

- (void) addTransaction // called when click save button
{
    // create a transaction from inputed info.
    RecurTrans* transaction = [RecurTrans MR_createEntity];
    transaction.amount = [amountTxtField.text floatValue];
    //transaction.date = dateAdd;
    transaction.notes = notesAdd;
    transaction.category = categoryAdd;
    transaction.walletid = walletAdd.id;
    if (categoryAdd.type == TYPE_EXPENSE)
        transaction.amount = transaction.amount * -1;
    //g_appDelegate.currentWallet.balance += transaction.amount;
    transaction.frequency = frequencyAdd;
    transaction.interval = intervalAdd;
    transaction.startDate = startDateAdd;
    if ([statusSwitch isOn])
        transaction.status = 0;
    else
        transaction.status = 1;
    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL success, NSError *error) {
        if (success) {
            NSLog(@"You successfully saved your context.");
            [self.navigationController popViewControllerAnimated:YES];
        } else if (error) {
            NSLog(@"Error saving context: %@", error.description);
        }
    }];
}

- (void) setWallet: (Wallet *) wallet
{
    walletAdd = wallet;
    [walletImgView setImage:[UIImage imageNamed:wallet.image]];
    walletNameLbl.text = wallet.name;
    currencySymbolLbl.text = wallet.currency.symbol;
}

- (void) setRepeatOption
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    NSString* startDate = [dateFormatter stringFromDate:startDateAdd];
    NSString* frequencyString;
    switch (frequencyAdd) {
        case 0:
            frequencyString = @"Repeat Daily";
            break;
        case 1:
            frequencyString = @"Repeat Weekly";
            break;
        case 2:
            frequencyString = @"Repeat Monthly";
            break;
        case 3:
            frequencyString = @"Repeat Yearly";
            break;
        default:
            frequencyString = @"Repeat Daily";
            break;
    }
    repeatOptionLbl.text = [NSString stringWithFormat:@"%@. From %@", frequencyString, startDate];
}

#pragma mark - Button Callbacks

- (IBAction)onClickSelectCategory:(id)sender {
    SelectCategoryVC *categoryVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SelectCategoryVC"];
    categoryVC.delegate = self;
    [self.navigationController pushViewController:categoryVC animated:YES];
}

- (IBAction)onClickNote:(id)sender {
    AddNoteVC *addNoteVC = [self.storyboard instantiateViewControllerWithIdentifier:@"AddNoteVC"];
    addNoteVC.delegate = self;
    addNoteVC.noteToEdit = notesAdd;
    [self.navigationController pushViewController:addNoteVC animated:YES];
}

- (IBAction)onClickWallet:(id)sender {
    SelectWalletVC *walletVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SelectWalletVC"];
    walletVC.delegate = self;
    [self.navigationController pushViewController:walletVC animated:YES];
}

- (IBAction)onClickRepeatOption:(id)sender {
    RepeatOptionTVC *repeatVC = [self.storyboard instantiateViewControllerWithIdentifier:@"RepeatOptionTVC"];
    repeatVC.delegate = self;
    repeatVC.frequency = frequencyAdd;
    repeatVC.interval = intervalAdd;
    repeatVC.startDate = startDateAdd;
    [self.navigationController pushViewController:repeatVC animated:YES];
}

- (IBAction)statusChanged:(id)sender {
    if ([statusSwitch isOn]) {
        statusLbl.text = @"Enabled";
    } else {
        statusLbl.text = @"Disabled";
    }
}

#pragma mark - Delegation Methods for VC
- (void) categoryUpdated:(Category *)category // called after select category
{
    categoryAdd = category;
    [categoryImgView setImage:[UIImage imageNamed:category.image]];
    categoryName.text = category.name;
    [self checkSave];
}

- (void) noteUpdated:(NSString *)notes // called after press back button in add note screen
{
    notesAdd = notes;
    if ([notesAdd isEqualToString:@""])
        notesLbl.text = @"Notes";
    else
        notesLbl.text = notes;
    [self checkSave];
}

- (void) walletUpdated:(Wallet *)wallet // called after select wallet
{
    [self setWallet:wallet];
}

- (void) repeatUpdated:(NSInteger)frequency interval:(NSInteger)interval startDate:(NSDate *)startDate
{
    frequencyAdd = frequency;
    intervalAdd = interval;
    startDateAdd = startDate;
    [self setRepeatOption];
}

- (IBAction)textFieldChanged:(UITextField *)sender {
    [self checkSave];
}

- (IBAction)textFieldEnded:(UITextField *)sender {
    NSNumberFormatter* nf = [[NSNumberFormatter alloc] init];
    nf.positiveFormat = @"0.##";
    amountTxtField.text = [NSString stringWithFormat:@"%@", [nf stringFromNumber: [NSNumber numberWithFloat: [amountTxtField.text floatValue]]]];
}

- (void) checkSave // check if transaction can be added.
{
    float fAmount = [amountTxtField.text floatValue];
    if (fAmount > 0.f && categoryAdd != nil) {
        [self.navigationItem.rightBarButtonItem setEnabled:YES];
    }
    else{
        [self.navigationItem.rightBarButtonItem setEnabled:NO];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
