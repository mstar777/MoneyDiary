//
//  AddNoteVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/23/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// ===================== this class is for add note. =================
#import "AddNoteVC.h"

@interface AddNoteVC ()
{
    __weak IBOutlet UITextView *noteTextView;
}
@end

@implementation AddNoteVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupNavigationBar];
    noteTextView.text = self.noteToEdit;
}

-(void) viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    if(self.delegate) {
        [self.delegate noteUpdated:noteTextView.text];
    }
}

- (void) setupNavigationBar
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    self.navigationItem.title = @"Note";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
