//
//  EditTransactionVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/24/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// ================= this class is for edit transaction. works almost same as a addtransaction vc ================
#import "EditTransactionVC.h"
#import "Constant.h"
#import "SelectCategoryVC.h"
#import "AddNoteVC.h"
#import "SelectWalletVC.h"
#import "PDTSimpleCalendarViewController.h"
#import "PDTSimpleCalendarViewCell.h"
#import "PDTSimpleCalendarViewHeader.h"

@interface EditTransactionVC () <SelectCategoryVCDelegate, AddNoteVCDelegate, SelectWalletVCDelegate, PDTSimpleCalendarViewDelegate>
{
    __weak IBOutlet UILabel *currencySymbolLbl;
    __weak IBOutlet UITextField *amountTxtField;
    __weak IBOutlet UIImageView *categoryImgView;
    __weak IBOutlet UILabel *categoryName;
    __weak IBOutlet UILabel *notesLbl;
    __weak IBOutlet UIImageView *walletImgView;
    __weak IBOutlet UILabel *dateLbl;
    __weak IBOutlet UILabel *walletNameLbl;
    __weak IBOutlet UILabel *eventLbl;
    
    PDTSimpleCalendarViewController *calendarViewController;
    NSString* notesAdd;
    Category* categoryAdd;
    NSDate* dateAdd;
    Wallet* walletAdd;
}
@end

@implementation EditTransactionVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setupNavigationBar];
    [self setData];
    
}

- (void) setData
{
    Wallet* wallet = [Wallet MR_findFirstByAttribute:@"id" withValue:self.transactionToEdit.walletid];
    [self setWallet:wallet];
    [self setDate:self.transactionToEdit.date];
    [self initCalendar:dateAdd];
    //[self categoryUpdated:self.transactionToEdit.category];
    categoryAdd = self.transactionToEdit.category;
    [categoryImgView setImage:[UIImage imageNamed:categoryAdd.image]];
    categoryName.text = categoryAdd.name;
    //[self noteUpdated:self.transactionToEdit.notes];
    notesAdd = self.transactionToEdit.notes;
    if ([notesAdd isEqualToString:@""])
        notesLbl.text = @"Notes";
    else
        notesLbl.text = self.transactionToEdit.notes;
    NSNumberFormatter* nf = [[NSNumberFormatter alloc] init];
    nf.positiveFormat = @"0.##";
    amountTxtField.text = [NSString stringWithFormat:@"%@", [nf stringFromNumber: [NSNumber numberWithFloat: fabs(self.transactionToEdit.amount)]]];
}

#pragma mark - Initialize
- (void) setupNavigationBar
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
                                              initWithTitle:@"Save"
                                              style:UIBarButtonItemStylePlain
                                              target:self
                                              action:@selector(saveTransaction)];
    [self.navigationItem.rightBarButtonItem setEnabled:NO];
    self.navigationItem.title = @"Edit Transaction";
}

- (void) saveTransaction
{
    //Transaction* transaction = [Transaction MR_createEntity];
    float prevAmount = self.transactionToEdit.amount;
    self.transactionToEdit.amount = [amountTxtField.text floatValue];
    self.transactionToEdit.date = dateAdd;
    self.transactionToEdit.notes = notesAdd;
    self.transactionToEdit.category = categoryAdd;
    self.transactionToEdit.walletid = walletAdd.id;
    if (categoryAdd.type == TYPE_EXPENSE)
        self.transactionToEdit.amount = self.transactionToEdit.amount * -1;
    g_appDelegate.currentWallet.balance += self.transactionToEdit.amount - prevAmount;
    
    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL success, NSError *error) {
        if (success) {
            NSLog(@"You successfully saved your context.");
            [self.navigationController popViewControllerAnimated:YES];
        } else if (error) {
            NSLog(@"Error saving context: %@", error.description);
        }
    }];
}

- (void) initCalendar : (NSDate *)date
{
    calendarViewController = [[PDTSimpleCalendarViewController alloc] init];
    //This is the default behavior, will display a full year starting the first of the current month
    [calendarViewController setDelegate:self];
    calendarViewController.weekdayHeaderEnabled = YES;
    calendarViewController.weekdayTextType = PDTSimpleCalendarViewWeekdayTextTypeShort;
    NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
    offsetComponents.month = -5;
    NSDate *lastDate =[calendarViewController.calendar dateByAddingComponents:offsetComponents toDate:date options:0];
    calendarViewController.firstDate = lastDate;
    [calendarViewController setSelectedDate:date];
    //[calendarViewController scrollToDate:[NSDate date] animated:NO];
    [calendarViewController scrollToSelectedDate:NO];
    [[PDTSimpleCalendarViewCell appearance] setCircleSelectedColor:[UIColor grayColor]];
    
    [calendarViewController setTitle:@"Pick Date"];
    if ([UIViewController instancesRespondToSelector:@selector(edgesForExtendedLayout)]) {
        [calendarViewController setEdgesForExtendedLayout:UIRectEdgeNone];
    }
}

- (void) setDate: (NSDate*) date
{
    dateAdd = date;
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"dd"];
    NSString* day = [df stringFromDate:date];
    [df setDateFormat:@"MMMM"];
    NSString* month = [df stringFromDate:date];
    [df setDateFormat:@"yyyy"];
    NSString* year = [df stringFromDate:date];
    
    NSInteger weekday = [[NSCalendar currentCalendar] component:NSCalendarUnitWeekday
                                                       fromDate:date];
    
    dateLbl.text = [NSString stringWithFormat:@"%@ %@ %@ %@", [self stringFromWeekDay:weekday], day, month, year];
}

- (void) setWallet: (Wallet *) wallet
{
    walletAdd = wallet;
    [walletImgView setImage:[UIImage imageNamed:wallet.image]];
    walletNameLbl.text = wallet.name;
    currencySymbolLbl.text = wallet.currency.symbol;
}

#pragma mark - Button Callbacks
- (IBAction)onClickSelectCategory:(id)sender {
    SelectCategoryVC *categoryVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SelectCategoryVC"];
    categoryVC.delegate = self;
    [self.navigationController pushViewController:categoryVC animated:YES];
}

- (IBAction)onClickNote:(id)sender {
    AddNoteVC *addNoteVC = [self.storyboard instantiateViewControllerWithIdentifier:@"AddNoteVC"];
    addNoteVC.delegate = self;
    addNoteVC.noteToEdit = notesAdd;
    [self.navigationController pushViewController:addNoteVC animated:YES];
}

- (IBAction)onClickDate:(id)sender {
    [self.navigationController pushViewController:calendarViewController animated:YES];
}

- (IBAction)onClickWallet:(id)sender {
    SelectWalletVC *walletVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SelectWalletVC"];
    walletVC.delegate = self;
    [self.navigationController pushViewController:walletVC animated:YES];
}
- (IBAction)onClickDelete:(id)sender {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warning"
                                                    message:@"Are you sure you want to delete this Transaction?"
                                                   delegate:self
                                          cancelButtonTitle:@"Confirm"
                                          otherButtonTitles:@"Cancel", nil];
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    // the user clicked OK
    if (buttonIndex == 0) {
        // do something here...
        g_appDelegate.currentWallet.balance -= self.transactionToEdit.amount;
        [self.transactionToEdit MR_deleteEntity];
        [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL success, NSError *error) {
            if (success) {
                NSLog(@"You successfully saved your context.");
                [self.navigationController popViewControllerAnimated:YES];
            } else if (error) {
                NSLog(@"Error saving context: %@", error.description);
            }
        }];
    }
}
#pragma mark - Delegation Methods for VC
- (void) categoryUpdated:(Category *)category
{
    categoryAdd = category;
    [categoryImgView setImage:[UIImage imageNamed:category.image]];
    categoryName.text = category.name;
    [self checkSave];
}

- (void) noteUpdated:(NSString *)notes
{
    notesAdd = notes;
    if ([notesAdd isEqualToString:@""])
        notesLbl.text = @"Notes";
    else
        notesLbl.text = notes;
    [self checkSave];
}

- (void) walletUpdated:(Wallet *)wallet
{
    [self setWallet:wallet];
    [self checkSave];
}

- (IBAction)textFieldChanged:(UITextField *)sender {
    [self checkSave];
}

- (IBAction)textFieldEnded:(UITextField *)sender {
    NSNumberFormatter* nf = [[NSNumberFormatter alloc] init];
    nf.positiveFormat = @"0.##";
    amountTxtField.text = [NSString stringWithFormat:@"%@", [nf stringFromNumber: [NSNumber numberWithFloat: [amountTxtField.text floatValue]]]];
    [self checkSave];
}

#pragma mark - PDTSimpleCalendarViewDelegate

- (void)simpleCalendarViewController:(PDTSimpleCalendarViewController *)controller didSelectDate:(NSDate *)date
{
    [self setDate:date];
    [self checkSave];
    //[self.navigationController popToViewController:controller animated:YES];
    //NSLog(@"Date Selected : %@",date);
    //NSLog(@"Date Selected with Locale %@", [date descriptionWithLocale:[NSLocale systemLocale]]);
}

- (UIColor *)simpleCalendarViewController:(PDTSimpleCalendarViewController *)controller circleColorForDate:(NSDate *)date
{
    return [UIColor whiteColor];
}

- (UIColor *)simpleCalendarViewController:(PDTSimpleCalendarViewController *)controller textColorForDate:(NSDate *)date
{
    return [UIColor orangeColor];
}

- (void) checkSave
{
    float fAmount = [amountTxtField.text floatValue];
    NSLog(@"%d %d %d %d %d", ![notesAdd isEqualToString:self.transactionToEdit.notes],
          fAmount != fabs(self.transactionToEdit.amount),
          ![categoryAdd isEqual:self.transactionToEdit.category],
          ![[NSCalendar currentCalendar] isDate:dateAdd inSameDayAsDate:self.transactionToEdit.date],
          ![walletAdd.id isEqualToString:self.transactionToEdit.walletid]);
    NSLog(@"%@ %@", dateAdd, self.transactionToEdit.date);
    if ((fAmount > 0.f && categoryAdd != nil) &&
        (![notesAdd isEqualToString:self.transactionToEdit.notes] ||
         fAmount != fabs(self.transactionToEdit.amount) ||
         ![categoryAdd isEqual:self.transactionToEdit.category] ||
         ![[NSCalendar currentCalendar] isDate:dateAdd inSameDayAsDate:self.transactionToEdit.date] ||
         ![walletAdd.id isEqualToString:self.transactionToEdit.walletid]
        ))
    {
        [self.navigationItem.rightBarButtonItem setEnabled:YES];
    }
    else{
        [self.navigationItem.rightBarButtonItem setEnabled:NO];
    }
}

- (NSString *) stringFromWeekDay:(NSInteger) weekDay
{
    switch (weekDay)
    {
        case 1:
            return @"Sunday";
            break;
        case 2:
            return @"Monday";
            break;
        case 3:
            return @"Tuesday";
            break;
        case 4:
            return @"Wednesday";
            break;
        case 5:
            return @"Thursday";
            break;
        case 6:
            return @"Friday";
            break;
        case 7:
            return @"Saturday";
            break;
        default:
            return @"Sunday";
            break;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
