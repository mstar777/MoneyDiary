//
//  RepeatOptionTVC.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 4/5/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol RepeatOptionTVCDelegate
- (void) repeatUpdated:(NSInteger)frequency interval:(NSInteger) interval startDate:(NSDate *) startDate;
@end

@interface RepeatOptionTVC : UITableViewController
@property (strong, nonatomic) id<RepeatOptionTVCDelegate> delegate;
@property (assign, nonatomic) NSInteger frequency;
@property (assign, nonatomic) NSInteger interval;
@property (strong, nonatomic) NSDate* startDate;
@end
