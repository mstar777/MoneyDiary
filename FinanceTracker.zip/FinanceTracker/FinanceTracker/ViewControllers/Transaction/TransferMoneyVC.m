//
//  TransferMoneyVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 4/4/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// ====================== this class is for transfer money. works almost same as a add or edit transaction vc ===============
#import "TransferMoneyVC.h"
#import "Constant.h"
#import "SelectCategoryVC.h"
#import "AddNoteVC.h"
#import "SelectWalletVC.h"
#import "PDTSimpleCalendarViewController.h"
#import "PDTSimpleCalendarViewCell.h"
#import "PDTSimpleCalendarViewHeader.h"

@interface TransferMoneyVC () <SelectCategoryVCDelegate, AddNoteVCDelegate, SelectWalletVCDelegate, PDTSimpleCalendarViewDelegate>
{
    __weak IBOutlet UITextField *amountTxtField;
    __weak IBOutlet UIImageView *sendWalletIcon;
    __weak IBOutlet UILabel *sendWalletName;
    __weak IBOutlet UIImageView *sendCategoryIcon;
    __weak IBOutlet UILabel *sendCategoryName;
    __weak IBOutlet UIImageView *receiveWalletIcon;
    __weak IBOutlet UILabel *receiveWalletName;
    __weak IBOutlet UILabel *noteLbl;
    __weak IBOutlet UILabel *dateLbl;
    
    PDTSimpleCalendarViewController *calendarViewController;
    NSString* notesAdd;
    Category* senderCategory;
    NSDate* dateAdd;
    Wallet* senderWallet;
    Wallet* receiverWallet;
    BOOL isSelectedSender;
}
@end

@implementation TransferMoneyVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setupNavigationBar];
    [self initCalendar];
    
    // initialize and set initial wallet and category for sender
    [self setSenderWallet:g_appDelegate.currentWallet];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"walletid ==[c] %@ AND name ==[c] %@", g_appDelegate.currentWallet.id, @"Withdraws"];
    Category* category = [Category MR_findFirstWithPredicate:predicate];
    [self setSenderCategory:category];
    notesAdd = @"";
    receiverWallet = nil;
    isSelectedSender = YES;
}

#pragma mark - Initialize
- (void) setupNavigationBar
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
                                              initWithTitle:@"Save"
                                              style:UIBarButtonItemStylePlain
                                              target:self
                                              action:@selector(transferMoney)];
    [self.navigationItem.rightBarButtonItem setEnabled:NO];
    self.navigationItem.title = @"Transfer Money";
}

- (void) transferMoney // called when click save button
{
    // create a transaction for sender wallet.
    Transaction* sendTransaction = [Transaction MR_createEntity];
    sendTransaction.amount = [amountTxtField.text floatValue];
    sendTransaction.date = dateAdd;
    sendTransaction.notes = notesAdd;
    sendTransaction.category = senderCategory;
    sendTransaction.walletid = senderWallet.id;
    if (senderCategory.type == TYPE_EXPENSE)
        sendTransaction.amount = sendTransaction.amount * -1;
    senderWallet.balance += sendTransaction.amount;
    
    // create a transaction for receiver wallet
    Transaction* receiveTransaction = [Transaction MR_createEntity];
    receiveTransaction.amount = [amountTxtField.text floatValue];
    receiveTransaction.date = dateAdd;
    receiveTransaction.notes = notesAdd;
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"walletid ==[c] %@ AND id ==[c] %@", receiverWallet.id, @"Miscellaneous_income"];
    Category* category = [Category MR_findFirstWithPredicate:predicate];
    receiveTransaction.category = category;
    receiveTransaction.walletid = receiverWallet.id;
    if (category.type == TYPE_EXPENSE)
        receiveTransaction.amount = receiveTransaction.amount * -1;
    receiverWallet.balance += receiveTransaction.amount;
    
    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL success, NSError *error) {
        if (success) {
            NSLog(@"You successfully saved your context.");
            [self.navigationController popViewControllerAnimated:YES];
        } else if (error) {
            NSLog(@"Error saving context: %@", error.description);
        }
    }];
}

- (void) initCalendar
{
    calendarViewController = [[PDTSimpleCalendarViewController alloc] init];
    //This is the default behavior, will display a full year starting the first of the current month
    [calendarViewController setDelegate:self];
    calendarViewController.weekdayHeaderEnabled = YES;
    calendarViewController.weekdayTextType = PDTSimpleCalendarViewWeekdayTextTypeShort;
    NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
    offsetComponents.month = -5;
    NSDate *lastDate =[calendarViewController.calendar dateByAddingComponents:offsetComponents toDate:[NSDate date] options:0];
    calendarViewController.firstDate = lastDate;
    [calendarViewController setSelectedDate:[NSDate date]];
    //[calendarViewController scrollToDate:[NSDate date] animated:NO];
    [calendarViewController scrollToSelectedDate:NO];
    [[PDTSimpleCalendarViewCell appearance] setCircleSelectedColor:[UIColor grayColor]];
    
    [calendarViewController setTitle:@"Pick Date"];
    if ([UIViewController instancesRespondToSelector:@selector(edgesForExtendedLayout)]) {
        [calendarViewController setEdgesForExtendedLayout:UIRectEdgeNone];
    }
}

- (void) setDate: (NSDate*) date
{
    dateAdd = date;
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"dd"];
    NSString* day = [df stringFromDate:date];
    [df setDateFormat:@"MMMM"];
    NSString* month = [df stringFromDate:date];
    [df setDateFormat:@"yyyy"];
    NSString* year = [df stringFromDate:date];
    
    NSInteger weekday = [[NSCalendar currentCalendar] component:NSCalendarUnitWeekday
                                                       fromDate:date];
    
    dateLbl.text = [NSString stringWithFormat:@"%@ %@ %@ %@", [self stringFromWeekDay:weekday], day, month, year];
}

- (void) setSenderWallet: (Wallet *) wallet
{
    senderWallet = wallet;
    [sendWalletIcon setImage:[UIImage imageNamed:wallet.image]];
    sendWalletName.text = wallet.name;
}

- (void) setReceiverWallet: (Wallet *) wallet
{
    receiverWallet = wallet;
    [receiveWalletIcon setImage:[UIImage imageNamed:wallet.image]];
    receiveWalletName.text = wallet.name;
}

- (void) setSenderCategory: (Category *) category
{
    senderCategory = category;
    [sendCategoryIcon setImage:[UIImage imageNamed:category.image]];
    sendCategoryName.text = category.name;
}

- (void) setNote: (NSString*) notes
{
    notesAdd = notes;
    noteLbl.text = notes;
}

#pragma mark - Button Callbacks

- (IBAction)onClickParentWallet:(id)sender {
    isSelectedSender = YES;
    SelectWalletVC *walletVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SelectWalletVC"];
    walletVC.delegate = self;
    [self.navigationController pushViewController:walletVC animated:YES];
}
- (IBAction)onClickParentCategory:(id)sender {
    if (senderWallet != nil) {
        SelectCategoryVC *categoryVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SelectCategoryVC"];
        categoryVC.delegate = self;
        categoryVC.prevVC = @"TransferMoneyVC";
        categoryVC.categoryType = 1;
        categoryVC.walletForCategory = senderWallet;
        [self.navigationController pushViewController:categoryVC animated:YES];
    }
    else
        [AppDelegate showMessage:@"Please select sender wallet first."];
    
}
- (IBAction)onClickReceiverWallet:(id)sender {
    isSelectedSender = NO;
    SelectWalletVC *walletVC = [self.storyboard instantiateViewControllerWithIdentifier:@"SelectWalletVC"];
    walletVC.delegate = self;
    [self.navigationController pushViewController:walletVC animated:YES];
}
- (IBAction)onClickNote:(id)sender {
    AddNoteVC *addNoteVC = [self.storyboard instantiateViewControllerWithIdentifier:@"AddNoteVC"];
    addNoteVC.delegate = self;
    addNoteVC.noteToEdit = notesAdd;
    [self.navigationController pushViewController:addNoteVC animated:YES];
}
- (IBAction)onClickDate:(id)sender {
    [self.navigationController pushViewController:calendarViewController animated:YES];
}
#pragma mark - Delegation Methods for VC
- (void)categoryUpdated:(Category *)category
{
    [self setSenderCategory:category];
    [self checkSave];
}

- (void)noteUpdated:(NSString *)notes
{
    notesAdd = notes;
    if ([notesAdd isEqualToString:@""])
        noteLbl.text = @"Note";
    else
        noteLbl.text = notes;
    [self checkSave];
}

- (void)walletUpdated:(Wallet *)wallet
{
    if (isSelectedSender) {
        if (![receiverWallet.id isEqualToString:wallet.id]) {
            if (![senderWallet.id isEqualToString:wallet.id])
            {
                senderCategory = nil;
                [sendCategoryIcon setImage:[UIImage imageNamed:@"emptyCategory.png"]];
                sendCategoryName.text = @"Select category";
            }
            [self setSenderWallet:wallet];
        }
        else
        {
            [AppDelegate showMessage:@"Sender and receive wallet should be different. please select different wallet."];
        }
    }
    else
    {
        if (senderWallet != nil && ![senderWallet.id isEqualToString:wallet.id]) {
            [self setReceiverWallet:wallet];
        }
        else if ([senderWallet.id isEqualToString:wallet.id])
        {
            [AppDelegate showMessage:@"Sender and receive wallet should be different. please select different wallet."];
        }
    }
    [self checkSave];
    
}
- (IBAction)textFieldChanged:(UITextField *)sender {
    [self checkSave];
}
- (IBAction)textFieldEnded:(UITextField *)sender {
    NSNumberFormatter* nf = [[NSNumberFormatter alloc] init];
    nf.positiveFormat = @"0.##";
    amountTxtField.text = [NSString stringWithFormat:@"%@", [nf stringFromNumber: [NSNumber numberWithFloat: [amountTxtField.text floatValue]]]];
}

#pragma mark - PDTSimpleCalendarViewDelegate

- (void)simpleCalendarViewController:(PDTSimpleCalendarViewController *)controller didSelectDate:(NSDate *)date
{
    [self setDate:date];
    [self checkSave];
    //[self.navigationController popToViewController:controller animated:YES];
    //NSLog(@"Date Selected : %@",date);
    //NSLog(@"Date Selected with Locale %@", [date descriptionWithLocale:[NSLocale systemLocale]]);
}

- (UIColor *)simpleCalendarViewController:(PDTSimpleCalendarViewController *)controller circleColorForDate:(NSDate *)date
{
    return [UIColor whiteColor];
}

- (UIColor *)simpleCalendarViewController:(PDTSimpleCalendarViewController *)controller textColorForDate:(NSDate *)date
{
    return [UIColor orangeColor];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) checkSave
{
    float fAmount = [amountTxtField.text floatValue];
    if (fAmount > 0.f && senderWallet != nil && senderCategory != nil && receiverWallet != nil) {
        [self.navigationItem.rightBarButtonItem setEnabled:YES];
    }
    else{
        [self.navigationItem.rightBarButtonItem setEnabled:NO];
    }
}

- (NSString *) stringFromWeekDay:(NSInteger) weekDay
{
    switch (weekDay)
    {
        case 1:
            return @"Sunday";
            break;
        case 2:
            return @"Monday";
            break;
        case 3:
            return @"Tuesday";
            break;
        case 4:
            return @"Wednesday";
            break;
        case 5:
            return @"Thursday";
            break;
        case 6:
            return @"Friday";
            break;
        case 7:
            return @"Saturday";
            break;
        default:
            return @"Sunday";
            break;
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


@end
