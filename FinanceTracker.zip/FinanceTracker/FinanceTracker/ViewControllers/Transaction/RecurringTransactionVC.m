//
//  RecurringTransactionVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 4/5/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import "RecurringTransactionVC.h"
#import "Constant.h"
#import "EditRecurringTransVC.h"

@interface RecurringTransactionVC ()
{
    NSMutableArray* transactionDataArray;
    __weak IBOutlet UITableView *transactionTableView;
    __weak IBOutlet NSLayoutConstraint *tableViewHeight;
}
@end

@implementation RecurringTransactionVC

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self fetchData];
    [transactionTableView reloadData];
}

- (void) viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    // this is for resize tableview to fit the list size
    CGFloat height = MIN(self.view.bounds.size.height, transactionTableView.contentSize.height);
    tableViewHeight.constant = height;
    [self.view layoutIfNeeded];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupNavigationBar];
    
}

#pragma mark - Initialize
- (void) setupNavigationBar
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
                                              initWithTitle:@"Add"
                                              style:UIBarButtonItemStylePlain
                                              target:self
                                              action:@selector(addTransaction)];
    //[self.navigationItem.rightBarButtonItem setEnabled:NO];
    self.navigationItem.title = @"Recurring Transactions";
}

- (void) addTransaction
{
    UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"AddRecurringTransVC"];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void) fetchData
{
    transactionDataArray = [[NSMutableArray alloc]init];
    NSArray* transactions = [RecurTrans MR_findByAttribute:@"walletid" withValue:g_appDelegate.currentWallet.id];
    transactionDataArray = [[transactions sortedArrayUsingComparator:^NSComparisonResult(RecurTrans *event1, RecurTrans *event2) {
        return [event2.startDate compare:event1.startDate];
    }] mutableCopy] ;
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)theTableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)theTableView numberOfRowsInSection:(NSInteger)section
{
    return [transactionDataArray count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 80;
}

// the cell will be returned to the tableView
- (UITableViewCell* )tableView:(UITableView* )theTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *reuseId = @"recurtranscell";
    UITableViewCell *cell = [theTableView dequeueReusableCellWithIdentifier:reuseId];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseId];
    }
    RecurTrans* transaction = [transactionDataArray objectAtIndex:indexPath.row];
    UIImageView* categoryImageView = [cell viewWithTag:10];
    categoryImageView.image = [UIImage imageNamed:transaction.category.image];
    
    UILabel* categoryNameLbl = [cell viewWithTag:20];
    categoryNameLbl.text = transaction.category.name;
    
    UILabel* noteLbl = [cell viewWithTag:30];
    noteLbl.text = transaction.notes;
    
    UILabel* balanceLbl = [cell viewWithTag:40];
    if (transaction.amount > 0.f)
        [balanceLbl setTextColor:UIColorFromRGB(0x3BAF4A)];
    else
        [balanceLbl setTextColor:UIColorFromRGB(0xFF2E2E)];
    NSNumberFormatter* nf = [[NSNumberFormatter alloc] init];
    nf.positiveFormat = @"0.##";
    balanceLbl.text = [NSString stringWithFormat:@"%@ %@", g_appDelegate.currentWallet.currency.symbol, [nf stringFromNumber: [NSNumber numberWithFloat: fabs(transaction.amount)]]];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    NSString* startDate = [dateFormatter stringFromDate:transaction.startDate];
    
    UILabel* dataLbl = [cell viewWithTag:50];
    dataLbl.text = [NSString stringWithFormat:@"%@", startDate];
    //[transaction MR_deleteEntity];
    //[[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
    
    return cell;
}

#pragma mark - UITableViewDelegate
// when user tap the row, what action you want to perform
- (void)tableView:(UITableView* )theTableView didSelectRowAtIndexPath:(NSIndexPath* )indexPath
{
    RecurTrans* transaction = [transactionDataArray objectAtIndex:indexPath.row];
    EditRecurringTransVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"EditRecurringTransVC"];
    vc.recurTransToEdit = transaction;
    [self.navigationController pushViewController:vc animated:YES];
    
    NSLog(@"selected %ld row", (long)indexPath.row);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
