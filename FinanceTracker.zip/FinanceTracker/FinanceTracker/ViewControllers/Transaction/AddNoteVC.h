//
//  AddNoteVC.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/23/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol AddNoteVCDelegate
- (void) noteUpdated:(NSString *)notes;
@end

@interface AddNoteVC : UIViewController
@property (strong, nonatomic) id<AddNoteVCDelegate> delegate;
@property (strong, nonatomic) NSString* noteToEdit;
@end
