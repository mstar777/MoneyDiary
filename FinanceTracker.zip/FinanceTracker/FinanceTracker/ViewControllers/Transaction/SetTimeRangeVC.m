//
//  SetTimeRangeVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 4/2/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// ============= this class is for set time range ===============
#import "SetTimeRangeVC.h"
#import "Constant.h"
#import "PDTSimpleCalendarViewController.h"
#import "PDTSimpleCalendarViewCell.h"
#import "PDTSimpleCalendarViewHeader.h"

@interface SetTimeRangeVC () <PDTSimpleCalendarViewDelegate>
{
    __weak IBOutlet UILabel *startDateLbl;
    __weak IBOutlet UILabel *endDateLbl;
    NSDate* startDate;
    NSDate* endDate;
    PDTSimpleCalendarViewController *calendarViewController;
    BOOL bSelStartDate;
}
@end

@implementation SetTimeRangeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    startDate = nil;
    endDate = nil;
    [self setupNavigationBar];
    [self initCalendar];
    bSelStartDate = YES;
    
}

#pragma mark - Initialize
- (void) setupNavigationBar
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
                                              initWithTitle:@"Done"
                                              style:UIBarButtonItemStylePlain
                                              target:self
                                              action:@selector(saveTimeRange)];
    //[self.navigationItem.rightBarButtonItem setEnabled:NO];
    self.navigationItem.title = @"Set Time Range";
}

- (void) initCalendar // initialize calendar
{
    calendarViewController = [[PDTSimpleCalendarViewController alloc] init];
    //This is the default behavior, will display a full year starting the first of the current month
    [calendarViewController setDelegate:self];
    calendarViewController.weekdayHeaderEnabled = YES;
    calendarViewController.weekdayTextType = PDTSimpleCalendarViewWeekdayTextTypeShort;
    NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
    offsetComponents.month = -5;
    NSDate *lastDate =[calendarViewController.calendar dateByAddingComponents:offsetComponents toDate:[NSDate date] options:0];
    calendarViewController.firstDate = lastDate;
    [calendarViewController setSelectedDate:[NSDate date]];
    //[calendarViewController scrollToDate:[NSDate date] animated:NO];
    [calendarViewController scrollToSelectedDate:NO];
    [[PDTSimpleCalendarViewCell appearance] setCircleSelectedColor:[UIColor grayColor]];
    
    [calendarViewController setTitle:@"Pick Date"];
    if ([UIViewController instancesRespondToSelector:@selector(edgesForExtendedLayout)]) {
        [calendarViewController setEdgesForExtendedLayout:UIRectEdgeNone];
    }
}

- (void) saveTimeRange // return selected time range value to previous viewcontroller
{
    if (startDate == nil){
        [AppDelegate showMessage:@"Please select start date."];
        return;
    }
    if (endDate == nil) {
        [AppDelegate showMessage:@"Please select end date."];
        return;
    }
    if ([startDate compare:endDate] == NSOrderedDescending) {
        [AppDelegate showMessage:@"End date must be later date than start date."];
        return;
    }
    if (self.delegate) {
        [self.delegate timeRangeUpdated:startDate endDate:endDate];
    }
}

- (IBAction)onClickStartDate:(id)sender { // called when select start date
    bSelStartDate = YES;
    [self.navigationController pushViewController:calendarViewController animated:YES];
}

- (IBAction)onClickEndDate:(id)sender { // called when select end date
    bSelStartDate = NO;
    [self.navigationController pushViewController:calendarViewController animated:YES];
}

#pragma mark - PDTSimpleCalendarViewDelegate
// this is delegate method. called after select date in calendar
- (void)simpleCalendarViewController:(PDTSimpleCalendarViewController *)controller didSelectDate:(NSDate *)date
{
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"dd"];
    NSString* day = [df stringFromDate:date];
    [df setDateFormat:@"MM"];
    NSString* month = [df stringFromDate:date];
    [df setDateFormat:@"yyyy"];
    NSString* year = [df stringFromDate:date];
    
    if (bSelStartDate) {
        startDate = date;
        startDateLbl.text = [NSString stringWithFormat:@"%@/%@/%@", day, month, year];
    }
    else
    {
        endDate = date;
        endDateLbl.text = [NSString stringWithFormat:@"%@/%@/%@", day, month, year];
    }
    
    //[self.navigationController popToViewController:controller animated:YES];
    //NSLog(@"Date Selected : %@",date);
    //NSLog(@"Date Selected with Locale %@", [date descriptionWithLocale:[NSLocale systemLocale]]);
}

- (UIColor *)simpleCalendarViewController:(PDTSimpleCalendarViewController *)controller circleColorForDate:(NSDate *)date
{
    return [UIColor whiteColor];
}

- (UIColor *)simpleCalendarViewController:(PDTSimpleCalendarViewController *)controller textColorForDate:(NSDate *)date
{
    return [UIColor orangeColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
