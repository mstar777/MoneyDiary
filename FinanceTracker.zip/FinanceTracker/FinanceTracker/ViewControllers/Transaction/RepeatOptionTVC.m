//
//  RepeatOptionTVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 4/5/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import "RepeatOptionTVC.h"
#import "PickerCells.h"

@interface RepeatOptionTVC () <PickerCellsDelegate, UIPickerViewDelegate, UIPickerViewDataSource>
{
    PickerCellsController *pickersController;
}
@end

@implementation RepeatOptionTVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    pickersController = [[PickerCellsController alloc] init];
    [pickersController attachToTableView:self.tableView tableViewsPriorDelegate:self withDelegate:self];
    
    UIPickerView *pickerView1 = [[UIPickerView alloc] init];
    pickerView1.delegate = self;
    pickerView1.dataSource = self;
    NSIndexPath *pickerIP1 = [NSIndexPath indexPathForRow:0 inSection:0];
    [pickersController addPickerView:pickerView1 forIndexPath:pickerIP1];
    [pickerView1 selectRow:self.frequency inComponent:0 animated:NO];
    
    UIPickerView *pickerView2 = [[UIPickerView alloc] init];
    pickerView2.delegate = self;
    pickerView2.dataSource = self;
    NSIndexPath *pickerIP2 = [NSIndexPath indexPathForRow:1 inSection:0];
    [pickersController addPickerView:pickerView2 forIndexPath:pickerIP2];
    [pickerView2 selectRow:self.interval inComponent:0 animated:NO];
    
    UIDatePicker *datePicker1 = [[UIDatePicker alloc] init];
    datePicker1.datePickerMode = UIDatePickerModeDate;
    datePicker1.date = self.startDate;
    NSIndexPath *path1 = [NSIndexPath indexPathForRow:2 inSection:0];
    [pickersController addDatePicker:datePicker1 forIndexPath:path1];
    
    [datePicker1 addTarget:self action:@selector(dateSelected:) forControlEvents:UIControlEventValueChanged];
}

-(void) viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    if(self.delegate) {
        [self.delegate repeatUpdated:self.frequency interval:self.interval startDate:self.startDate];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 3;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellReuseId = @"tableviewcell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellReuseId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellReuseId];
    }
    UILabel* valueLabel = [cell viewWithTag:20];
    
    id picker = [pickersController pickerForOwnerCellIndexPath:indexPath];
    if (picker) {
        
        if ([picker isKindOfClass:UIPickerView.class]) {
            UIPickerView *pickerView = (UIPickerView *)picker;
            if (indexPath.row == 0) {
                NSInteger selectedRow = [pickerView selectedRowInComponent:0];
                NSString *title = [self pickerView:pickerView titleForRow:selectedRow forComponent:0];
                valueLabel.text = title;
                self.frequency = selectedRow;
                NSIndexPath* newIndex = [NSIndexPath indexPathForRow:indexPath.row + 1 inSection:0];
                UIPickerView *nextPickerView = [pickersController pickerForOwnerCellIndexPath:newIndex];
                [nextPickerView reloadAllComponents];/*
                //[nextPickerView selectRow:self.interval inComponent:0 animated:NO];
                [self.tableView reloadRowsAtIndexPaths:@[newIndex] withRowAnimation:UITableViewRowAnimationAutomatic];*/
            }
            else if (indexPath.row == 1)
            {
                NSInteger selectedRow = [pickerView selectedRowInComponent:0];
                NSString *title = [self pickerView:pickerView titleForRow:selectedRow forComponent:0];
                valueLabel.text = title;
                self.interval = selectedRow;
            }
            
        } else if ([picker isKindOfClass:UIDatePicker.class]) {
            UIDatePicker *datePicker = (UIDatePicker *)picker;
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            if (datePicker.datePickerMode == UIDatePickerModeDate) {
                [dateFormatter setDateFormat:@"dd-MM-yyyy"];
            } else if (datePicker.datePickerMode == UIDatePickerModeDateAndTime) {
                [dateFormatter setDateFormat:@"dd-MM-yyyy:HH-mm"];
            } else {
                [dateFormatter setDateFormat:@"HH-mm"];
            }
            valueLabel.text = [dateFormatter stringFromDate:[(UIDatePicker *)picker date]];
            self.startDate = [(UIDatePicker *)picker date];
        }
    }
    
    UILabel* titleLbl = [cell viewWithTag:10];
    switch (indexPath.row) {
        case 0:
            titleLbl.text = @"Frequency";
            break;
        case 1:
            titleLbl.text = @"Every";
            break;
        case 2:
            titleLbl.text = @"From";
            break;
        default:
            titleLbl.text = @"From";
            break;
    }
    return cell;
}

#pragma mark - UIPickerView DataSource

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    NSIndexPath *ip = [pickersController indexPathForPicker:pickerView];
    if (ip.row == 0)
        return 4;
    else if (ip.row == 1)
        return 100;
    else
        return 4;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    NSString *text;
    NSIndexPath *ip = [pickersController indexPathForPicker:pickerView];
    if (ip.row == 0){
        switch (row) {
            case 0:
                text = @"Repeat Daily";
                break;
            case 1:
                text = @"Repeat Weekly";
                break;
            case 2:
                text = @"Repeat Monthly";
                break;
            case 3:
                text = @"Repeat Yearly";
                break;
            default:
                text = @"Repeat Daily";
                break;
        }
    }
    else if (ip.row == 1){
        NSString* prefix;
        switch (self.frequency) {
            case 0:
                prefix = @"day";
                break;
            case 1:
                prefix = @"week";
                break;
            case 2:
                prefix = @"month";
                break;
            case 3:
                prefix = @"year";
                break;
            default:
                text = @"day";
                break;
        }
        text = [NSString stringWithFormat:@"%li %@", (long)row + 1, prefix];
    }
    else
        return 0;
    return text;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    [self.tableView reloadData];
    /*NSIndexPath *ip = [pickersController indexPathForPicker:pickerView];
    if (ip) {
        [self.tableView reloadRowsAtIndexPaths:@[ip] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    */
}

#pragma mark - PickerCellsDelegate

- (void)pickerCellsController:(PickerCellsController *)controller willExpandTableViewContent:(UITableView *)tableView forHeight:(CGFloat)expandHeight {
    NSLog(@"expand height = %.f", expandHeight);
}

- (void)pickerCellsController:(PickerCellsController *)controller willCollapseTableViewContent:(UITableView *)tableView forHeight:(CGFloat)expandHeight {
    NSLog(@"collapse height = %.f", expandHeight);
}

#pragma mark - Actions

- (void)dateSelected:(UIDatePicker *)sender {
    NSIndexPath *ip = [pickersController indexPathForPicker:sender];
    if (ip) {
        [self.tableView reloadRowsAtIndexPaths:@[ip] withRowAnimation:UITableViewRowAnimationAutomatic];
    }
}
@end
