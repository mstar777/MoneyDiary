//
//  SearchTransactionTableVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 4/5/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// ====================== this class is for search transaction ===============
#import "SearchTransactionTableVC.h"
#import "Constant.h"
#import "EditTransactionVC.h"

@interface SearchTransactionTableVC () <UISearchBarDelegate>
{
    __weak IBOutlet UISearchBar *searchBar;
    IBOutlet UITableView *transactionTableView;
    NSMutableArray* transactionDataArray;
}
@end

@implementation SearchTransactionTableVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupNavigationBar];
    [self fetchData];
    [transactionTableView reloadData];
}

- (void) setupNavigationBar
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    
    self.navigationItem.title = @"Search for transaction";
}

- (void)fetchData // fetch transaction data
{
    transactionDataArray = [[NSMutableArray alloc]init];
    //NSArray* transactions = [Transaction MR_findByAttribute:@"walletid" withValue:g_appDelegate.currentWallet.id];
    NSArray* transactions = [Transaction MR_findAllWithPredicate:[NSPredicate predicateWithFormat:@"walletid ==[c] %@ AND (notes contains[cd] %@ OR category.name contains[cd] %@)", g_appDelegate.currentWallet.id, searchBar.text, searchBar.text]];
    
    NSArray *sortedArray = [transactions sortedArrayUsingComparator:^NSComparisonResult(Transaction *event1, Transaction *event2) {
        return [event2.date compare:event1.date];
    }];
    
    for (int i = 0; i < sortedArray.count; i++) {
        if (i == 0)
        {
            NSMutableArray* array = [[NSMutableArray alloc]init];;
            [transactionDataArray addObject:array];
            Transaction* trans = [sortedArray objectAtIndex:i];
            [array addObject:trans];
        }
        else
        {
            NSMutableArray* lastArray = [transactionDataArray lastObject];
            Transaction* prevTrans = [sortedArray objectAtIndex:i - 1];
            Transaction* curTrans = [sortedArray objectAtIndex:i];
            NSLog(@"total array count == %@", curTrans.date);
            if ([[NSCalendar currentCalendar] isDate:prevTrans.date inSameDayAsDate:curTrans.date]){
                //if ([prevTrans.date compare:curTrans.date] == NSOrderedSame) {
                [lastArray addObject:curTrans];
            }
            else
            {
                NSMutableArray* array = [[NSMutableArray alloc]init];
                [transactionDataArray addObject:array];
                [array addObject:curTrans];
            }
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return transactionDataArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [[transactionDataArray objectAtIndex:section] count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 50;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    NSMutableArray* dayTransactionArray = [transactionDataArray objectAtIndex:section];
    Transaction* firstTransaction = [dayTransactionArray objectAtIndex:0];
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 50)];
    // 4 * 69 (width of label) + 3 * 8 (distance between labels) = 300
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 25, 150, 22)];
    label.font=[label.font fontWithSize:12];
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"dd"];
    NSString* day = [df stringFromDate:firstTransaction.date];
    [df setDateFormat:@"MMMM"];
    NSString* month = [df stringFromDate:firstTransaction.date];
    [df setDateFormat:@"yyyy"];
    NSString* year = [df stringFromDate:firstTransaction.date];
    
    NSInteger weekday = [[NSCalendar currentCalendar] component:NSCalendarUnitWeekday
                                                       fromDate:firstTransaction.date];
    
    label.text = [NSString stringWithFormat:@"%@ %@ %@ %@", [self stringFromWeekDay:weekday], day, month, year];
    
    [headerView addSubview:label];
    return headerView;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSMutableArray* dayTransactionArray = [transactionDataArray objectAtIndex:indexPath.section];
    static NSString *currencyIdentifier = @"transactioncell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:currencyIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:currencyIdentifier];
    }
    
    Transaction* transaction = [dayTransactionArray objectAtIndex:indexPath.row];
    UIImageView* categoryImageView = [cell viewWithTag:10];
    categoryImageView.image = [UIImage imageNamed:transaction.category.image];
    
    UILabel* categoryNameLbl = [cell viewWithTag:20];
    categoryNameLbl.text = transaction.category.name;
    
    UILabel* noteLbl = [cell viewWithTag:30];
    noteLbl.text = transaction.notes;
    
    UILabel* balanceLbl = [cell viewWithTag:40];
    if (transaction.amount > 0.f)
        [balanceLbl setTextColor:UIColorFromRGB(0x3BAF4A)];
    else
        [balanceLbl setTextColor:UIColorFromRGB(0xFF2E2E)];
    NSNumberFormatter* nf = [[NSNumberFormatter alloc] init] ;
    nf.positiveFormat = @"0.##";
    balanceLbl.text = [NSString stringWithFormat:@"%@ %@", g_appDelegate.currentWallet.currency.symbol, [nf stringFromNumber: [NSNumber numberWithFloat: fabs(transaction.amount)]]];
    
    return cell;
}


#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView* )tableView didSelectRowAtIndexPath:(NSIndexPath* )indexPath
{
    NSMutableArray* dayTransactionArray = [transactionDataArray objectAtIndex:indexPath.section];
    Transaction* transaction = [dayTransactionArray objectAtIndex:indexPath.row];
    EditTransactionVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"EditTransactionVC"];
    vc.transactionToEdit = transaction;
    [self.navigationController pushViewController:vc animated:YES];
    
    NSLog(@"selected %ld row", (long)indexPath.row);
}


#pragma mark - Search Bar Delegate
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText { // called everytime typing keyword in searchbar
    if ([searchBar.text length] > 0) { // if keyword length is big than 0, search start
        [self doSearch];
    } else {
        [self fetchData];
        [transactionTableView reloadData];
    }
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
    [searchBar resignFirstResponder];
    // Clear search bar text
    searchBar.text = @"";
    // Hide the cancel button
    searchBar.showsCancelButton = NO;
    // Do a default fetch of the beers
    [self fetchData];
    [transactionTableView reloadData];
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    searchBar.showsCancelButton = YES;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    [searchBar resignFirstResponder];
    [self doSearch];
}

- (void)doSearch {
    // 1. Get the text from the search bar.
    //NSString *searchText = searchBar.text;
    
    [self fetchData];
    [transactionTableView reloadData];
}

- (NSString *) stringFromWeekDay:(NSInteger) weekDay
{
    switch (weekDay)
    {
        case 1:
            return @"Sunday";
            break;
        case 2:
            return @"Monday";
            break;
        case 3:
            return @"Tuesday";
            break;
        case 4:
            return @"Wednesday";
            break;
        case 5:
            return @"Thursday";
            break;
        case 6:
            return @"Friday";
            break;
        case 7:
            return @"Saturday";
            break;
        default:
            return @"Sunday";
            break;
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
