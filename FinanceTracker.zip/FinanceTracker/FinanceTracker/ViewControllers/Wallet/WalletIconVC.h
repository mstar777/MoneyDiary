//
//  WalletIconVC.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/14/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol WalletIconVCDelegate
- (void) iconUpdated:(NSString *)iconName;
@end

@interface WalletIconVC : UIViewController
@property (strong, nonatomic) id<WalletIconVCDelegate> delegate;
@property (strong, nonatomic) NSString* prevVC;
@end
