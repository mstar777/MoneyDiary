//
//  AddWalletVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/15/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// ============== this class is for add new wallet
#import "AddWalletVC.h"
#import "Constant.h"
#import "WalletIconVC.h"
#import "CurrencyTableVC.h"

@interface AddWalletVC () <WalletIconVCDelegate, CurrencyTableVCDelegate>
{
    __weak IBOutlet UIButton *walletIconBtn;
    __weak IBOutlet UITextField *walletNameTxtField;
    __weak IBOutlet UILabel *currencyNameLabel;
    __weak IBOutlet UILabel *currencySymbolLabel;
    __weak IBOutlet UITextField *balanceTxtField;
    NSString* iconFileName;
    Currency* newCurrency;
    
}
@end

@implementation AddWalletVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupNavigationBar];
    
    [self setWalletIcon:@"wallet1"];
    newCurrency = nil;
}
- (IBAction)textFieldChanged:(UITextField *)sender {
    [self checkSave];
}
- (IBAction)textFieldChangedForBal:(UITextField *)sender {
    [self checkSave];
}

- (void) setWalletIcon:(NSString*) filename
{
    iconFileName = filename;
    [walletIconBtn setImage:[UIImage imageNamed:iconFileName] forState:UIControlStateNormal];
}

- (void) setupNavigationBar
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
                                              initWithTitle:@"Save"
                                              style:UIBarButtonItemStylePlain
                                              target:self
                                              action:@selector(saveWallet)];
    [self.navigationItem.rightBarButtonItem setEnabled:NO];
    self.navigationItem.title = @"Add Wallet";
}

- (void) saveWallet // create new wallet
{
    Wallet* newWallet = [Wallet MR_createEntity];
    newWallet.name = walletNameTxtField.text;
    newWallet.balance = [balanceTxtField.text floatValue];
    newWallet.image = iconFileName;
    newWallet.id = [[NSUUID UUID] UUIDString];
    newWallet.userid = g_appDelegate.currentUser.id;
    newWallet.currency = newCurrency;
    
    [AppDelegate createCategory:newWallet.id];
    /*
    // ==== Initial Transaction ====
    Transaction* transaction = [Transaction MR_createEntity];
    transaction.amount = newWallet.balance;
    transaction.date = [NSDate date];
    transaction.notes = @"Initial Balance";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"walletid ==[c] %@ AND id ==[c] %@", newWallet.id, @"Miscellaneous"];
    Category* category = [Category MR_findFirstWithPredicate:predicate];
    transaction.category = category;
    transaction.walletid = newWallet.id;
    */
    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL success, NSError *error) {
        if (success) {
            NSLog(@"You successfully saved your context.");
            [self.navigationController popViewControllerAnimated:YES];
        } else if (error) {
            NSLog(@"Error saving context: %@", error.description);
        }
    }];
}
- (IBAction)onClickCurrency:(id)sender {
    CurrencyTableVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"CurrencyTableVC"];
    vc.delegate = self;
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)onClickChangeIcon:(id)sender {
    WalletIconVC *walletVC = [self.storyboard instantiateViewControllerWithIdentifier:@"WalletIconVC"];
    walletVC.delegate = self;
    [self.navigationController pushViewController:walletVC animated:YES];
}

#pragma mark - WalletIconVCDelegate
- (void) iconUpdated:(NSString *)iconName {
    [self setWalletIcon:iconName];
}

#pragma mark - CurrencyTableVCDelegate
- (void) currencyUpdated:(Currency *)currency {
    currencyNameLabel.text = currency.name;
    currencySymbolLabel.text = currency.symbol;
    newCurrency = currency;
    [self checkSave];
}

- (void) checkSave // method for check if save can be performed
{
    if ([walletNameTxtField.text length] > 0 && [balanceTxtField.text length] > 0 && newCurrency != nil) {
        [self.navigationItem.rightBarButtonItem setEnabled:YES];
    }
    else
        [self.navigationItem.rightBarButtonItem setEnabled:NO];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
