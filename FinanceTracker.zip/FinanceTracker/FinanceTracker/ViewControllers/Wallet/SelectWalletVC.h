//
//  SelectWalletVC.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/14/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constant.h"

@protocol SelectWalletVCDelegate
- (void) walletUpdated:(Wallet *)wallet;
@end

@interface SelectWalletVC : UIViewController
@property (strong, nonatomic) id<SelectWalletVCDelegate> delegate;
@property (strong, nonatomic) NSString* prevVC;
@end
