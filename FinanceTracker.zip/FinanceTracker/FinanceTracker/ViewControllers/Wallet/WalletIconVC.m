//
//  WalletIconVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/14/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// ============= this class displays wallet or category icons ===========
#import "WalletIconVC.h"

@interface WalletIconVC ()

@end

@implementation WalletIconVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
    
}

#pragma mark - CollectionView DataSource
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView*)collectionView
{
    return 1;
}
-(NSInteger)collectionView:(UICollectionView*)collectionView numberOfItemsInSection:(NSInteger)section
{
    if ([self.prevVC isEqualToString:@"category"])
        return 50;
    else
        return 7;
}

-(UICollectionViewCell*)collectionView:(UICollectionView*)collectionView cellForItemAtIndexPath:(NSIndexPath*)indexPath
{
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    UIImageView *imageView = [cell viewWithTag:10];
    if ([self.prevVC isEqualToString:@"category"])
    {
        NSString* filename = [NSString stringWithFormat:@"category%ld.png", indexPath.row + 1];
        imageView.image = [UIImage imageNamed:filename];
    }
    else
    {
        NSString* filename = [NSString stringWithFormat:@"wallet%ld", indexPath.row + 1];
        imageView.image = [UIImage imageNamed:filename];
    }
    
    
    return cell;
}

#pragma mark -CollectionView Delegate
-(void)collectionView:(UICollectionView* )collectionView didSelectItemAtIndexPath:(NSIndexPath* )indexPath  {
    NSString* filename;
    if ([self.prevVC isEqualToString:@"category"])
        filename = [NSString stringWithFormat:@"category%ld.png", indexPath.row + 1];
    else
        filename = [NSString stringWithFormat:@"wallet%ld", indexPath.row + 1];
    
    if(self.delegate) {
        [self.delegate iconUpdated:filename];
        [self.navigationController popViewControllerAnimated:YES];
        //[self popVC];
    }
}

- (void) popVC {
    CATransition* transition = [CATransition animation];
    transition.duration = 0.5;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionReveal;
    transition.subtype = kCATransitionFromBottom;
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController popViewControllerAnimated:NO];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
