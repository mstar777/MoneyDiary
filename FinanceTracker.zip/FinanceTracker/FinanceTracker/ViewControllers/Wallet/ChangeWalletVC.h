//
//  ChangeWalletVC.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/16/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constant.h"

@interface ChangeWalletVC : UIViewController

@property (strong, nonatomic) Wallet* walletToEdit;

@end
