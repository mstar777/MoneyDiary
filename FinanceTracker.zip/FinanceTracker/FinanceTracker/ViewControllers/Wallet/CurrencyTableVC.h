//
//  CurrencyTableVC.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/15/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constant.h"

@protocol CurrencyTableVCDelegate
- (void) currencyUpdated:(Currency *)currency;
@end

@interface CurrencyTableVC : UITableViewController
@property (strong, nonatomic) id<CurrencyTableVCDelegate> delegate;
@end
