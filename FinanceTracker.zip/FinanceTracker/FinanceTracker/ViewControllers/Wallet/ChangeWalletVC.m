//
//  ChangeWalletVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/16/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// ================= this class is for edit one wallet. works almost same as a addwallet
#import "ChangeWalletVC.h"
#import "WalletIconVC.h"
#import "CurrencyTableVC.h"

@interface ChangeWalletVC () <WalletIconVCDelegate, CurrencyTableVCDelegate>
{
    __weak IBOutlet UIButton *walletIconBtn;
    __weak IBOutlet UITextField *walletNameTxtField;
    __weak IBOutlet UILabel *currencyNameLabel;
    __weak IBOutlet UILabel *currencySymbolLabel;
    __weak IBOutlet UITextField *balanceTxtField;
    NSString* iconFileName;
    Currency* newCurrency;
}
@end

@implementation ChangeWalletVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupNavigationBar];
    [self setData];
    
    //newCurrency = nil;
}

- (void) setData // set wallet data to be edited
{
    [self setWalletIcon: self.walletToEdit.image];
    walletNameTxtField.text = self.walletToEdit.name;
    currencyNameLabel.text = self.walletToEdit.currency.name;
    currencySymbolLabel.text = self.walletToEdit.currency.symbol;
    balanceTxtField.text = [NSString stringWithFormat:@"%.2f", self.walletToEdit.balance];
    newCurrency = self.walletToEdit.currency;
}

- (IBAction)textFieldChanged:(UITextField *)sender {
    [self checkSave];
}
- (IBAction)textFieldChangedForBal:(UITextField *)sender {
    [self checkSave];
}

- (void) setWalletIcon:(NSString*) filename
{
    iconFileName = filename;
    [walletIconBtn setImage:[UIImage imageNamed:iconFileName] forState:UIControlStateNormal];
}

- (void) setupNavigationBar
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
                                              initWithTitle:@"Save"
                                              style:UIBarButtonItemStylePlain
                                              target:self
                                              action:@selector(updateWallet)];
    [self.navigationItem.rightBarButtonItem setEnabled:NO];
    self.navigationItem.title = @"Edit Wallet";
}

- (void) updateWallet
{
    self.walletToEdit.name = walletNameTxtField.text;
    self.walletToEdit.balance = [balanceTxtField.text floatValue];
    self.walletToEdit.image = iconFileName;
    //self.walletToEdit.id = [[NSUUID UUID] UUIDString];
    //self.walletToEdit.userid = g_appDelegate.currentUser.id;
    self.walletToEdit.currency = newCurrency;
    
    //[g_appDelegate.currentUser addWalletObject:newWallet];
    
    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL success, NSError *error) {
        if (success) {
            NSLog(@"You successfully saved your context.");
            [self.navigationController popViewControllerAnimated:YES];
        } else if (error) {
            NSLog(@"Error saving context: %@", error.description);
        }
    }];
}
- (IBAction)onClickCurrency:(id)sender {
    CurrencyTableVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"CurrencyTableVC"];
    vc.delegate = self;
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)onClickChangeIcon:(id)sender {
    WalletIconVC *walletVC = [self.storyboard instantiateViewControllerWithIdentifier:@"WalletIconVC"];
    walletVC.delegate = self;
    [self.navigationController pushViewController:walletVC animated:YES];
}

#pragma mark - WalletIconVCDelegate
- (void) iconUpdated:(NSString *)iconName {
    [self setWalletIcon:iconName];
    [self checkSave];
}

#pragma mark - CurrencyTableVCDelegate
- (void) currencyUpdated:(Currency *)currency {
    currencyNameLabel.text = currency.name;
    currencySymbolLabel.text = currency.symbol;
    newCurrency = currency;
    [self checkSave];
}

- (void) checkSave
{
    if (([walletNameTxtField.text length] > 0 && [balanceTxtField.text length] > 0 && newCurrency != nil )&&
        (![walletNameTxtField.text isEqualToString:self.walletToEdit.name] ||
        ![balanceTxtField.text isEqualToString:[NSString stringWithFormat:@"%.2f", self.walletToEdit.balance]] ||
        ![iconFileName isEqualToString:self.walletToEdit.image] || ![newCurrency isEqual:self.walletToEdit.currency])) {
        [self.navigationItem.rightBarButtonItem setEnabled:YES];
    }
    else
        [self.navigationItem.rightBarButtonItem setEnabled:NO];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)onClickTransferMoney:(id)sender {
}
- (IBAction)onClickDeleteWallet:(id)sender {
    if ([self.walletToEdit.id isEqualToString:g_appDelegate.currentWallet.id]) {
        NSArray* wallets = [Wallet MR_findByAttribute:@"userid" withValue:g_appDelegate.currentUser.id];
        if (wallets.count > 1) {
            [AppDelegate showMessage:@"Please make active another wallet before delete active wallet."];
        }
        else
        {
            [AppDelegate showMessage:@"You must have at least one wallet active"];
        }
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warning"
                                                        message:@"Are you sure you want to delete this wallet?\nIf the wallet is deleted all the transactions and information link to the wallet would be deleted too."
                                                       delegate:self
                                              cancelButtonTitle:@"YES"
                                              otherButtonTitles:@"NO", nil];
        [alert show];
        
        
    }
    
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    // the user clicked OK
    if (buttonIndex == 0) {
        // do something here...
        [self.walletToEdit MR_deleteEntity];
        [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL success, NSError *error) {
            if (success) {
                NSLog(@"You successfully saved your context.");
                [self.navigationController popViewControllerAnimated:YES];
            } else if (error) {
                NSLog(@"Error saving context: %@", error.description);
            }
        }];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
