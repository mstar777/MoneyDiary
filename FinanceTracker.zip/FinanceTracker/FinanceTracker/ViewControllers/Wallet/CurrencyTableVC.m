//
//  CurrencyTableVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/15/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// this class shows list of currency
#import "CurrencyTableVC.h"

@interface CurrencyTableVC () <UISearchBarDelegate>
{
    NSArray* currencys;
    __weak IBOutlet UISearchBar *currencySearchBar;
    IBOutlet UITableView *currencyTableView;
}
@end

@implementation CurrencyTableVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self fetchData];
}

- (void)fetchData
{
    currencys = [Currency MR_findAllSortedBy:@"name" ascending:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return currencys.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *currencyIdentifier = @"walletcell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:currencyIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:currencyIdentifier];
    }
    Currency* currency = [currencys objectAtIndex:indexPath.row];
    UILabel* label = cell.textLabel;
    label.text = currency.name;
    
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView* )tableView didSelectRowAtIndexPath:(NSIndexPath* )indexPath
{
    //UITableViewCell *cell = [theTableView cellForRowAtIndexPath:indexPath];
    Currency* currency = [currencys objectAtIndex:indexPath.row];
    [self.delegate currencyUpdated:currency];
    [self.navigationController popViewControllerAnimated:YES];
    
    NSLog(@"selected %ld row", (long)indexPath.row);
}

#pragma mark - Search Bar Delegate
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    if ([currencySearchBar.text length] > 0) {
        [self doSearch];
    } else {
        [self fetchData];
        [currencyTableView reloadData];
    }
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
    [currencySearchBar resignFirstResponder];
    // Clear search bar text
    currencySearchBar.text = @"";
    // Hide the cancel button
    currencySearchBar.showsCancelButton = NO;
    // Do a default fetch of the beers
    [self fetchData];
    [currencyTableView reloadData];
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    currencySearchBar.showsCancelButton = YES;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    [currencySearchBar resignFirstResponder];
    [self doSearch];
}

- (void)doSearch { // search if there is matched currency
    // 1. Get the text from the search bar.
    NSString *searchText = currencySearchBar.text;
    
    currencys = [Currency MR_findAllSortedBy:@"name" ascending:YES withPredicate:[NSPredicate predicateWithFormat:@"name contains[c] %@", searchText]];
    
    // 3. Reload the table to show the query results.
    [currencyTableView reloadData];
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
