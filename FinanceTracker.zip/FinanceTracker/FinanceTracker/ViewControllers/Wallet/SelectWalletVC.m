//
//  SelectWalletVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/14/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// ============= this class is for showing wallet list when click wallet icon in main transaction screen.
#import "SelectWalletVC.h"
#import "Constant.h"

@interface SelectWalletVC ()
{
    __weak IBOutlet UITableView *walletTableView;
    NSMutableArray* walletDataArray;
    __weak IBOutlet NSLayoutConstraint *tableViewHeight;
    
}
@end

@implementation SelectWalletVC

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
     [self fetchWalletData]; // fetch wallet data for tableview
    [walletTableView reloadData]; // refresh the tableview
    
}
/*
-(void)viewDidLayoutSubviews
{
    CGFloat height = MIN(self.view.bounds.size.height, walletTableView.contentSize.height);
    tableViewHeight.constant = height;
    [self.view layoutIfNeeded];
}
*/
- (void) viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    // this is for resize tableview to fit the list size
    CGFloat height = MIN(self.view.bounds.size.height, walletTableView.contentSize.height);
    tableViewHeight.constant = height;
    [self.view layoutIfNeeded];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setupNavigationBar];
}

- (IBAction)onClickAddWallet:(id)sender { // when click add wallet button
    UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"AddWalletVC"];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void) setupNavigationBar // initialize navigation bar
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    if ([self.prevVC isEqualToString:@"TransactionVC"])
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
                                              initWithTitle:@"Edit"
                                              style:UIBarButtonItemStylePlain
                                              target:self
                                              action:@selector(editWallet)];
        
    self.navigationItem.title = @"Select Wallet";
}

- (void) fetchWalletData // fetch list of wallet
{
    walletDataArray = [[NSMutableArray alloc] init];
    
    walletDataArray = [[Wallet MR_findByAttribute:@"userid" withValue:g_appDelegate.currentUser.id] mutableCopy];
    
}

- (void) editWallet // when click edit wallet
{
    UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"EditWalletVC"];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)theTableView
{
    return 1; // section number
}

- (NSInteger)tableView:(UITableView *)theTableView numberOfRowsInSection:(NSInteger)section
{
    return [walletDataArray count]; // wallet array count
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 44; // cell height pixel
}

// the cell will be returned to the tableView
- (UITableViewCell* )tableView:(UITableView* )theTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    Wallet* wallet = [walletDataArray objectAtIndex:indexPath.row];
    static NSString *walletIdentifier = @"walletcell";
    UITableViewCell *cell = [theTableView dequeueReusableCellWithIdentifier:walletIdentifier];
     
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:walletIdentifier];
    }
    // set wallet icon
    UIImageView* walletIconImage = [cell viewWithTag:10];
    //walletIconImage.contentMode = UIViewContentModeScaleAspectFit;
    [walletIconImage setImage:[UIImage imageNamed:wallet.image]];
    // set wallet name
    UILabel* walletNameLbl = [cell viewWithTag:20];
    walletNameLbl.text = wallet.name;
    // set wallet balance
    UILabel* walletBalanceLbl = [cell viewWithTag:30];
    walletBalanceLbl.text = [NSString stringWithFormat:@"%@ %.02f", wallet.currency.symbol, wallet.balance];
    
    if ([self.prevVC isEqualToString:@"TransactionVC"]){
        if ([wallet isEqual:g_appDelegate.currentWallet])
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        else
            cell.accessoryType = UITableViewCellAccessoryNone;
    }

    return cell;
}

#pragma mark - UITableViewDelegate
// when user tap the row, what action you want to perform
- (void)tableView:(UITableView* )theTableView didSelectRowAtIndexPath:(NSIndexPath* )indexPath
{
    // get selected wallet and set it as a current wallet
    Wallet* wallet = [walletDataArray objectAtIndex:indexPath.row];
    if ([self.prevVC isEqualToString:@"TransactionVC"]){
        if (![wallet isEqual:g_appDelegate.currentWallet]) {
            g_appDelegate.currentWallet = wallet;
            g_appDelegate.currentUser.activewalletid = wallet.id;
            //[g_appDelegate setUserAccountInfo:g_appDelegate.currentUser.id];
            [walletTableView reloadData];
            [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
        }
    }
    else
    {
        if(self.delegate) {
            [self.delegate walletUpdated:wallet];
        }
    }
    [self.navigationController popViewControllerAnimated:YES];
    NSLog(@"selected %ld row", (long)indexPath.row);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
