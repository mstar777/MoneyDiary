//
//  EditWalletVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/16/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// ============= this class is for edit wallets. works almost same as select wallet vc ===========
#import "EditWalletVC.h"
#import "Constant.h"
#import "ChangeWalletVC.h"

@interface EditWalletVC ()
{
    __weak IBOutlet UITableView *walletTableView;
    NSMutableArray* walletDataArray;
    __weak IBOutlet NSLayoutConstraint *tableViewHeight;
}
@end

@implementation EditWalletVC

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    /*Wallet* wallet = [Wallet MR_findFirstByAttribute:@"id" withValue:g_appDelegate.currentUser.activewalletid];
    if (wallet == nil) {
        UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"StartingVC"];
        [self.navigationController pushViewController:vc animated:YES];
    }*/
    [self fetchWalletData];
    [walletTableView reloadData];
}

- (void) viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    CGFloat height = MIN(self.view.bounds.size.height, walletTableView.contentSize.height);
    tableViewHeight.constant = height;
    [self.view layoutIfNeeded];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupNavigationBar];
}

- (void) setupNavigationBar
{
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
                                              initWithTitle:@"Add"
                                              style:UIBarButtonItemStylePlain
                                              target:self
                                              action:@selector(addWallet)];
    self.navigationItem.title = @"My Wallets";
}

- (void) fetchWalletData
{
    walletDataArray = [[NSMutableArray alloc] init];
    
    walletDataArray = [[Wallet MR_findByAttribute:@"userid" withValue:g_appDelegate.currentUser.id] mutableCopy];
    
}

- (void) addWallet
{
    UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"AddWalletVC"];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)theTableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)theTableView numberOfRowsInSection:(NSInteger)section
{
    return [walletDataArray count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 44;
}

// the cell will be returned to the tableView
- (UITableViewCell* )tableView:(UITableView* )theTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    Wallet* wallet = [walletDataArray objectAtIndex:indexPath.row];
    static NSString *walletIdentifier = @"walletcell";
    UITableViewCell *cell = [theTableView dequeueReusableCellWithIdentifier:walletIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:walletIdentifier];
    }
    UIImageView* walletIconImage = [cell viewWithTag:10];
    //walletIconImage.contentMode = UIViewContentModeScaleAspectFit;
    [walletIconImage setImage:[UIImage imageNamed:wallet.image]];
    UILabel* walletNameLbl = [cell viewWithTag:20];
    walletNameLbl.text = wallet.name;
    UILabel* walletBalanceLbl = [cell viewWithTag:30];
    walletBalanceLbl.text = [NSString stringWithFormat:@"%@ %.2f", wallet.currency.symbol, wallet.balance];
    /*
    if ([wallet isEqual:g_appDelegate.currentWallet])
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    else
        cell.accessoryType = UITableViewCellAccessoryNone;
    */
    return cell;
}

#pragma mark - UITableViewDelegate
// when user tap the row, what action you want to perform
- (void)tableView:(UITableView* )theTableView didSelectRowAtIndexPath:(NSIndexPath* )indexPath
{
    //UITableViewCell *cell = [theTableView cellForRowAtIndexPath:indexPath];
    Wallet* wallet = [walletDataArray objectAtIndex:indexPath.row];
    ChangeWalletVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"ChangeWalletVC"];
    vc.walletToEdit = wallet;
    
    [self.navigationController pushViewController:vc animated:YES];
    
    NSLog(@"selected %ld row", (long)indexPath.row);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
