//
//  LoginVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/19/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// =============== This class is for login ==============
#import "LoginVC.h"
#import "Constant.h"

@interface LoginVC ()
{
    __weak IBOutlet UITextField *emailTxtField;
    __weak IBOutlet UITextField *passwordTxtField;
    __weak IBOutlet UIButton *loginBtn;
}
@end

@implementation LoginVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    loginBtn.layer.cornerRadius = 5;
    loginBtn.layer.borderWidth = 2;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)onClickLogin:(id)sender {
    NSString* email = emailTxtField.text;
    NSString* password = passwordTxtField.text;
    
    if (email.length == 0) {
        [AppDelegate showMessage:@"Please input the Email address."];
        [emailTxtField becomeFirstResponder];
        return;
    }
    
    if (password.length == 0) {
        [AppDelegate showMessage:@"Please input the password."];
        [passwordTxtField becomeFirstResponder];
        return;
    }
    
    BOOL isSameAccount = NO;
    NSArray* users = [User MR_findAll];
    for (int i = 0; i < users.count; i++) {
        User* user = [users objectAtIndex:i];
        if ([user.email isEqualToString:email] && [user.pass isEqualToString:password]) {
            [g_appDelegate setUserAccountInfo:user.id];
            isSameAccount = YES;
            Wallet* wallet = [Wallet MR_findFirstByAttribute:@"id" withValue:g_appDelegate.currentUser.activewalletid];
            // if there isn't any wallet created for logged in user, go to starting vc for create wallet.
            if (wallet == nil) {
                UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"StartingVC"];
                [self.navigationController pushViewController:vc animated:YES];
            }
            else       // else go to main tab.
            {
                g_appDelegate.currentWallet = wallet;
                UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"MyTabVC"];
                [self.navigationController pushViewController:vc animated:YES];
            }
        }
    }
    if (!isSameAccount) {
        [AppDelegate showMessage:@"Wrong email and password"];
        [emailTxtField becomeFirstResponder];
    }
    
    
    
}
- (IBAction)onClickSignUp:(id)sender { // when singup button clicked
    UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"SignUpVC"];
    [self.navigationController pushViewController:vc animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
