//
//  WelcomeVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/1/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

//======== App Starts from here =======//
//This class has just simple action.
// if user click start, go to login.

#import "WelcomeVC.h"
#import "StartingVC.h"
#import "MyTabVC.h"
#import "Constant.h"

@interface WelcomeVC ()
{
    __weak IBOutlet UIButton *startBtn;
    
}
@end

@implementation WelcomeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [[self navigationController] setNavigationBarHidden:YES animated:YES]; // In this screen, we don't need navigation bar on top.
    startBtn.layer.cornerRadius = 5;
    startBtn.layer.borderWidth = 2;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)onClickStart:(id)sender { // start button clicked
    
    if (g_appDelegate.currentUser == nil){ // if there isn't any user created, go to login screen
        UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginVC"];
        [self.navigationController pushViewController:vc animated:YES];
    }
    else{                                   // else go to startingVC or main transaction view.
        Wallet* wallet = [Wallet MR_findFirstByAttribute:@"id" withValue:g_appDelegate.currentUser.activewalletid];
        if (wallet == nil) {                   // if there isn't any wallet created for logged in user, go to starting vc for create wallet.
            UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"StartingVC"];
            [self.navigationController pushViewController:vc animated:YES];
        }
        else                                   // else go to main tab.
        {
            g_appDelegate.currentWallet = wallet;
            UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"MyTabVC"];
            [self.navigationController pushViewController:vc animated:YES];
        }
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
