//
//  StartingVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/1/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// ============= This screen is for create new wallet for a user logged in ==============
#import "StartingVC.h"
#import "KPDropMenu.h"
#import "Constant.h"
#import "WalletIconVC.h"

@interface StartingVC () <KPDropMenuDelegate, WalletIconVCDelegate>
{
    __weak IBOutlet UIButton *continueBtn;
    __weak IBOutlet KPDropMenu *currencyDropDown;
    __weak IBOutlet UITextField *walletNameTxtField;
    __weak IBOutlet UITextField *initialBalanceTxtField;
    __weak IBOutlet UIButton *walletIconBtn;
    
    NSInteger selectedCurrency;
    NSString* iconFileName;
}
@end

@implementation StartingVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    continueBtn.layer.cornerRadius = 5;
    continueBtn.layer.borderWidth = 2;
    
    // This is for display currency list.
    NSArray* currencys = [Currency MR_findAllSortedBy:@"name" ascending:YES];
    
    NSMutableArray *currencyNames = [[NSMutableArray alloc] init];
    for (int i = 0; i < currencys.count; i++) {
        Currency* currency = [currencys objectAtIndex:i];
        [currencyNames addObject:currency.name];
    }
    // initialize currency dropdown
    currencyDropDown.delegate = self;
    currencyDropDown.items = currencyNames;
    currencyDropDown.titleTextAlignment = NSTextAlignmentLeft;
    currencyDropDown.titleColor = UIColorFromRGB(0x4281D0);
    currencyDropDown.itemTextColor = UIColorFromRGB(0x4281D0);
    currencyDropDown.itemFontSize = 13;
    currencyDropDown.itemTextAlignment = NSTextAlignmentLeft;
    //selectedCurrency = -1;
    
    //iconFileName = @"wallet1";
    [self setWalletIcon:@"wallet1"];
}

- (void) setWalletIcon:(NSString*) filename
{
    iconFileName = filename;
    [walletIconBtn setImage:[UIImage imageNamed:iconFileName] forState:UIControlStateNormal];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onClickContinue:(id)sender {
    NSString* walletName = walletNameTxtField.text;
    NSString* initialBal = initialBalanceTxtField.text;
    if (selectedCurrency == -1) {
        [AppDelegate showMessage:@"Please select your currency."];
        return;
    }
    if (walletName.length == 0) {
        [AppDelegate showMessage:@"Please input the Wallet Name."];
        [walletNameTxtField becomeFirstResponder];
        return;
    }
    if (initialBal.length == 0) {
        [AppDelegate showMessage:@"Please input the Initial Balance."];
        [initialBalanceTxtField becomeFirstResponder];
        return;
    }
    // create new wallet
    Wallet* newWallet = [Wallet MR_createEntity];
    newWallet.name = walletName;
    newWallet.balance = [initialBal floatValue];
    newWallet.image = iconFileName;
    newWallet.id = [[NSUUID UUID] UUIDString];
    newWallet.userid = g_appDelegate.currentUser.id;
    
    // set currency into wallet
    NSArray* currencys = [Currency MR_findAllSortedBy:@"name" ascending:YES];
    Currency* currency = [currencys objectAtIndex:selectedCurrency];
    newWallet.currency = currency;
    
    //[g_appDelegate.currentUser addWalletObject:newWallet];
    g_appDelegate.currentWallet = newWallet;
    g_appDelegate.currentUser.activewalletid = newWallet.id;
    
    // create initial categories for created wallet.
    [AppDelegate createCategory:newWallet.id];
    
    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL success, NSError *error) {
        if (success) {
            NSLog(@"You successfully saved your context.");
            
            UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"MyTabVC"];
            [self.navigationController pushViewController:vc animated:YES];
        } else if (error) {
            NSLog(@"Error saving context: %@", error.description);
        }
    }];
    
}

#pragma mark - KPDropMenu Delegate Methods

 -(void)didSelectItem : (KPDropMenu *) dropMenu atIndex : (int) atIntedex{ // called when select currency
     selectedCurrency = atIntedex;
 /*if(dropMenu == brandNameDropView)
 {
 PMPBrandColourDetail *brandColourDetail = [sendArray objectAtIndex:atIntedex];
 lblBrandName.text = brandColourDetail.brandName;
 lblCollection.text = brandColourDetail.collectionName;
 lblColorRange.text = brandColourDetail.colourName;
 }*/
 }
 
 -(void)didShow:(KPDropMenu *)dropMenu{
 NSLog(@"didShow");
 }
 
 -(void)didHide:(KPDropMenu *)dropMenu{
 NSLog(@"didHide");
 }

- (IBAction)onClickIcon:(id)sender { // when click icon
    WalletIconVC *walletVC = [self.storyboard instantiateViewControllerWithIdentifier:@"WalletIconVC"];
    walletVC.delegate = self;
    [self.navigationController pushViewController:walletVC animated:YES];
    //[self pushVC:walletVC];
}
/*
- (void) pushVC:(UIViewController *)dstVC {
    CATransition* transition = [CATransition animation];
    transition.duration = 0.5;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionMoveIn;
    transition.subtype = kCATransitionFromTop;
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController pushViewController:dstVC animated:NO];
}*/
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
#pragma mark - WalletIconVCDelegate
- (void) iconUpdated:(NSString *)iconName { // delegate method after select wallet icon in walleticon vc.
    [self setWalletIcon:iconName];
}

@end
