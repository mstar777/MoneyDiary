//
//  SignUpVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/19/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import "SignUpVC.h"
#import "Constant.h"

@interface SignUpVC ()
{
    __weak IBOutlet UITextField *emailTxtField;
    __weak IBOutlet UITextField *passwordTxtField;
    __weak IBOutlet UIButton *signupBtn;
    __weak IBOutlet UITextField *confirmPassTxtField;
    
}
@end

@implementation SignUpVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [[self navigationController] setNavigationBarHidden:NO animated:YES];
    signupBtn.layer.cornerRadius = 5;
    signupBtn.layer.borderWidth = 2;
}
- (IBAction)onClickSignUp:(id)sender {
    NSString* email = emailTxtField.text;
    NSString* password = passwordTxtField.text;
    NSString* rePassword = confirmPassTxtField.text;
    
    if (email.length == 0) {
        [AppDelegate showMessage:@"Please input the Email address."];
        [emailTxtField becomeFirstResponder];
        return;
    }
    
    if (password.length == 0) {
        [AppDelegate showMessage:@"Please input the password."];
        [passwordTxtField becomeFirstResponder];
        return;
    }
    
    if (rePassword.length == 0) {
        [AppDelegate showMessage:@"Please input the confirm password."];
        [confirmPassTxtField becomeFirstResponder];
        return;
    }
    
    if(![self validateEmailWithString:email]) {
        [AppDelegate showMessage:@"Please input email again"];
        return;
    }
    
    if(password.length<6) {
        [AppDelegate showMessage:@"Password must have at least 6 characters"];
        return;
    }
    
    if(![password isEqualToString:rePassword]) {
        [AppDelegate showMessage:@"Please input password again"];
        return;
    }
    
    // check if there is same existing account
    BOOL isSameAccount = NO;
    NSArray* users = [User MR_findAll];
    for (int i = 0; i < users.count; i++) {
        User* user = [users objectAtIndex:i];
        if ([user.email isEqualToString:email]) {
            isSameAccount = YES;
        }
    }
    // if there isn't same account, create new user
    if (!isSameAccount) {
        User* user = [User MR_createEntity];
        user.name = [[email componentsSeparatedByString:@"@"] objectAtIndex:0];
        user.email = email;
        user.pass = password;
        user.id = [[NSUUID UUID] UUIDString];
        
        [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL success, NSError *error) {
            if (success) {
                NSLog(@"You successfully saved your context.");
                [g_appDelegate setUserAccountInfo:user.id];     // save the account info to userdefault
                Wallet* wallet = [Wallet MR_findFirstByAttribute:@"id" withValue:g_appDelegate.currentUser.activewalletid]; // same like welcomevc, loginvc
                if (wallet == nil) {
                    UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"StartingVC"];
                    [self.navigationController pushViewController:vc animated:YES];
                }
                else
                {
                    g_appDelegate.currentWallet = wallet;
                    UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"MyTabVC"];
                    [self.navigationController pushViewController:vc animated:YES];
                }
            } else if (error) {
                NSLog(@"Error saving context: %@", error.description);
            }
        }];
        
    }
    else
    {
        [AppDelegate showMessage:@"The email has been already userd."];
        [emailTxtField becomeFirstResponder];
    }
}

- (IBAction)onClickLogin:(id)sender { // when click login button
    UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginVC"];
    [self.navigationController pushViewController:vc animated:YES];
}

- (BOOL)validateEmailWithString:(NSString*)email // check if email is correct format
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
