//
//  TransactionVC.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/9/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
// ===================== this class displays main transactions. this is main screen after login.
#import "TransactionVC.h"
#import "Constant.h"
#import "SelectWalletVC.h"
#import "EditTransactionVC.h"
#import "SetTimeRangeVC.h"

@interface TransactionVC () <SetTimeRangeVCDelegate>
{
    __weak IBOutlet UIView *accBalanceView;
    __weak IBOutlet UILabel *accBalanceLabel;
    __weak IBOutlet UILabel *inflowLabel;
    __weak IBOutlet UILabel *outflowLabel;
    __weak IBOutlet UILabel *balanceLabel;
    __weak IBOutlet UITableView *mainTableView;
    __weak IBOutlet UIButton *accountBtn;
    __weak IBOutlet UILabel *timeRangeLbl;
    NSMutableArray* transactionDataArray;
    NSDate* startDate;
    NSDate* endDate;
    BOOL isSortByCategory;
}
@end

@implementation TransactionVC
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    accBalanceView.layer.cornerRadius = 50;
    accBalanceView.clipsToBounds = YES;
    
    [self addRecurTrans];
    [self setBalances];
    [self fetchTransactionData];
    [mainTableView reloadData];
    [self updateTimeLabel];
    [accountBtn setImage:[UIImage imageNamed:g_appDelegate.currentWallet.image] forState:UIControlStateNormal];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSDateComponents *components = [[NSCalendar currentCalendar] components:(NSCalendarUnitEra | NSYearCalendarUnit | NSMonthCalendarUnit) fromDate:[NSDate date]];
    components.day = 1;
    
    startDate = [[NSCalendar currentCalendar] dateFromComponents:components];
    endDate = [NSDate date];
    [self updateTimeLabel];
    
}

#pragma mark - Initialize

- (void) addRecurTrans
{
    NSArray* recurTransArr = [RecurTrans MR_findByAttribute:@"walletid" withValue:g_appDelegate.currentWallet.id];
    for (int i = 0; i < recurTransArr.count; i++) {
        RecurTrans* recurTrans = [recurTransArr objectAtIndex:i];
        NSDate *endRecurDate = [NSDate date];
        NSDate *startRecurDate = recurTrans.startDate;
        
        if ([startRecurDate compare:endRecurDate] != NSOrderedDescending && recurTrans.status == 0) {
            if (recurTrans.frequency == 0) {
                unsigned int unitFlags = NSCalendarUnitDay;
                NSDateComponents *comps = [[NSCalendar currentCalendar] components:unitFlags fromDate:startRecurDate  toDate:endRecurDate  options:0];
                NSInteger days = [comps day];
                
                if (days >= 0) {
                    NSInteger addCount;
                    if (days == 0)
                        addCount = 1;
                    else
                        addCount = days / (recurTrans.interval + 1) + 1;
                    for (int j = 0; j < addCount; j++) {
                        NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
                        offsetComponents.day = j * (recurTrans.interval + 1);
                        NSDate *newDate =[[NSCalendar currentCalendar] dateByAddingComponents:offsetComponents toDate:startRecurDate options:0];
                        [self createNewTransaction:recurTrans newDate:newDate];
                        if (j >= addCount - 1){
                            offsetComponents.day = (j + 1) * (recurTrans.interval + 1);
                            newDate =[[NSCalendar currentCalendar] dateByAddingComponents:offsetComponents toDate:startRecurDate options:0];
                            recurTrans.startDate = newDate;
                            [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
                        }
                        
                    }
                }
            }
            else if (recurTrans.frequency == 1) {
                unsigned int unitFlags = NSCalendarUnitDay;
                NSDateComponents *comps = [[NSCalendar currentCalendar] components:unitFlags fromDate:startRecurDate  toDate:endRecurDate  options:0];
                NSInteger days = [comps day];
                
                if (days >= 0) {
                    
                    NSInteger addCount;
                    if (days == 0)
                        addCount = 1;
                    else
                        addCount = (days / 7) / (recurTrans.interval + 1) + 1;
                    for (int j = 0; j < addCount; j++) {
                        NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
                        offsetComponents.day = j * (recurTrans.interval + 1) * 7;
                        NSDate *newDate =[[NSCalendar currentCalendar] dateByAddingComponents:offsetComponents toDate:startRecurDate options:0];
                        [self createNewTransaction:recurTrans newDate:newDate];
                        if (j >= addCount - 1){
                            offsetComponents.day = (j + 1) * (recurTrans.interval + 1) * 7;
                            newDate =[[NSCalendar currentCalendar] dateByAddingComponents:offsetComponents toDate:startRecurDate options:0];
                            recurTrans.startDate = newDate;
                            [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
                        }
                        
                    }
                }
                
            }
            else if (recurTrans.frequency == 2) {
                unsigned int unitFlags = NSCalendarUnitMonth;
                NSDateComponents *comps = [[NSCalendar currentCalendar] components:unitFlags fromDate:startRecurDate  toDate:endRecurDate  options:0];
                NSInteger months = [comps month];
                if (months >= 0) {
                    
                    NSInteger addCount;
                    if (months == 0)
                        addCount = 1;
                    else
                        addCount = months / (recurTrans.interval + 1) + 1;
                    for (int j = 0; j < addCount; j++) {
                        NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
                        offsetComponents.month = j * (recurTrans.interval + 1);
                        NSDate *newDate =[[NSCalendar currentCalendar] dateByAddingComponents:offsetComponents toDate:startRecurDate options:0];
                        [self createNewTransaction:recurTrans newDate:newDate];
                        if (j >= addCount - 1){
                            offsetComponents.month = (j + 1) * (recurTrans.interval + 1);
                            NSDate *newDate =[[NSCalendar currentCalendar] dateByAddingComponents:offsetComponents toDate:startRecurDate options:0];
                            recurTrans.startDate = newDate;
                            [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
                        }
                        
                    }
                }
                
            }
            else if (recurTrans.frequency == 3) {
                unsigned int unitFlags = NSCalendarUnitYear;
                NSDateComponents *comps = [[NSCalendar currentCalendar] components:unitFlags fromDate:startRecurDate  toDate:endRecurDate  options:0];
                NSInteger year = [comps year];
                if (year >= 0) {
                    //NSInteger addCount = year / (recurTrans.interval + 1);
                    NSInteger addCount;
                    if (year == 0)
                        addCount = 1;
                    else
                        addCount = year / (recurTrans.interval + 1) + 1;
                    
                    for (int j = 0; j < addCount; j++) {
                        NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
                        offsetComponents.year = j * (recurTrans.interval + 1);
                        NSDate *newDate =[[NSCalendar currentCalendar] dateByAddingComponents:offsetComponents toDate:startRecurDate options:0];
                        [self createNewTransaction:recurTrans newDate:newDate];
                        if (j >= addCount - 1){
                            offsetComponents.year = (j + 1) * (recurTrans.interval + 1);
                            NSDate *newDate =[[NSCalendar currentCalendar] dateByAddingComponents:offsetComponents toDate:startRecurDate options:0];
                            recurTrans.startDate = newDate;
                            [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
                        }
                        
                    }
                }
             
             }
        }
        
    }
}

- (void) createNewTransaction: (RecurTrans *) recurTrans newDate: (NSDate *) newDate
{
    Transaction* transaction = [Transaction MR_createEntity];
    transaction.amount = recurTrans.amount;
    transaction.date = newDate;
    transaction.notes = recurTrans.notes;
    transaction.category = recurTrans.category;
    transaction.walletid = recurTrans.walletid;
    //if (categoryAdd.type == TYPE_EXPENSE)
    //    transaction.amount = transaction.amount * -1;
    g_appDelegate.currentWallet.balance += transaction.amount;
}

- (void) setBalances
{
    NSNumberFormatter *currencyFormatter = [[NSNumberFormatter alloc] init];
    [currencyFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
    [currencyFormatter setCurrencySymbol:[NSString stringWithFormat:@"%@ ", g_appDelegate.currentWallet.currency.symbol]];
    NSString* accBalanceText = [currencyFormatter stringFromNumber:[NSNumber numberWithFloat:g_appDelegate.currentWallet.balance]];
    accBalanceLabel.text = accBalanceText;
    
    float inFlow = [self calculateInflow:startDate endDate:endDate];
    NSString* inflowText = [currencyFormatter stringFromNumber:[NSNumber numberWithFloat:inFlow]];
    inflowLabel.text = inflowText;
    
    float outFlow = [self calculateOutFlow:startDate endDate:endDate];
    NSString* outflowText = [currencyFormatter stringFromNumber:[NSNumber numberWithFloat:fabs(outFlow)]];
    outflowLabel.text = outflowText;
    float balance = inFlow - fabs(outFlow);
    if (balance > 0.f){
        [balanceLabel setTextColor:UIColorFromRGB(0x3BAF4A)];
        [accBalanceLabel setTextColor:UIColorFromRGB(0x3BAF4A)];
    }
    else{
        [balanceLabel setTextColor:UIColorFromRGB(0xFF2E2E)];
        [accBalanceLabel setTextColor:UIColorFromRGB(0xFF2E2E)];
    }
    
    NSString* balanceText = [currencyFormatter stringFromNumber:[NSNumber numberWithFloat:balance]];
    balanceLabel.text = balanceText;
    //accBalanceLabel.text = balanceText;
}

- (float) calculateInflow: (NSDate *) startDate endDate: (NSDate *) endDate
{
    float result = 0.f;
    NSArray* transactions;
    if (startDate == nil && endDate == nil)
        transactions = [Transaction MR_findByAttribute:@"walletid" withValue:g_appDelegate.currentWallet.id];
    else
    {
        transactions = [Transaction MR_findByAttribute:@"walletid" withValue:g_appDelegate.currentWallet.id];
        NSMutableArray* tempArray = [[NSMutableArray alloc] init];
        for (int i = 0; i < transactions.count; i++) {
            Transaction* transaction = [transactions objectAtIndex:i];
            if ([startDate compare:transaction.date] == NSOrderedAscending && [endDate compare:transaction.date] == NSOrderedDescending) {
                [tempArray addObject:transaction];
            }
        }
        transactions = tempArray;
    }
    for (int i = 0; i < transactions.count; i++) {
        Transaction* trans = [transactions objectAtIndex:i];
        if (trans.amount > 0)
            result += trans.amount;
    }
    return result;
}

- (float) calculateOutFlow: (NSDate *) startDate endDate: (NSDate *) endDate
{
    float result = 0.f;
    NSArray* transactions;
    if (startDate == nil && endDate == nil)
        transactions = [Transaction MR_findByAttribute:@"walletid" withValue:g_appDelegate.currentWallet.id];
    else
    {
        transactions = [Transaction MR_findByAttribute:@"walletid" withValue:g_appDelegate.currentWallet.id];
        NSMutableArray* tempArray = [[NSMutableArray alloc] init];
        for (int i = 0; i < transactions.count; i++) {
            Transaction* transaction = [transactions objectAtIndex:i];
            if ([startDate compare:transaction.date] == NSOrderedAscending && [endDate compare:transaction.date] == NSOrderedDescending) {
                [tempArray addObject:transaction];
            }
        }
        transactions = tempArray;
    }
    for (int i = 0; i < transactions.count; i++) {
        Transaction* trans = [transactions objectAtIndex:i];
        if (trans.amount < 0)
            result += trans.amount;
    }
    //result *= -1.f;
    return result;
}

- (void) fetchTransactionData
{
    transactionDataArray = [[NSMutableArray alloc]init];
    NSArray* transactions = [Transaction MR_findByAttribute:@"walletid" withValue:g_appDelegate.currentWallet.id];
    NSMutableArray* filteredArray = [[NSMutableArray alloc]init];
    for (int i = 0; i < transactions.count; i++) {
        Transaction* transaction = [transactions objectAtIndex:i];
        if (startDate == nil && endDate == nil) {
            [filteredArray addObject:transaction];
        }
        else
        {
            if ([[NSCalendar currentCalendar] isDate:endDate inSameDayAsDate:[NSDate date]])
                endDate = [NSDate date];
            if ([startDate compare:transaction.date] == NSOrderedAscending && [endDate compare:transaction.date] == NSOrderedDescending) {
                [filteredArray addObject:transaction];
            }
        }
    }
    NSArray *sortedArray = [filteredArray sortedArrayUsingComparator:^NSComparisonResult(Transaction *event1, Transaction *event2) {
        return [event2.date compare:event1.date];
    }];
    if (!isSortByCategory) {
        
        for (int i = 0; i < sortedArray.count; i++) {
            if (i == 0)
            {
                NSMutableArray* array = [[NSMutableArray alloc]init];;
                [transactionDataArray addObject:array];
                Transaction* trans = [sortedArray objectAtIndex:i];
                [array addObject:trans];
            }
            else
            {
                NSMutableArray* lastArray = [transactionDataArray lastObject];
                Transaction* prevTrans = [sortedArray objectAtIndex:i - 1];
                Transaction* curTrans = [sortedArray objectAtIndex:i];
                NSLog(@"total array count == %@", curTrans.date);
                if ([[NSCalendar currentCalendar] isDate:prevTrans.date inSameDayAsDate:curTrans.date]){
                    //if ([prevTrans.date compare:curTrans.date] == NSOrderedSame) {
                    [lastArray addObject:curTrans];
                }
                else
                {
                    NSMutableArray* array = [[NSMutableArray alloc]init];;
                    [transactionDataArray addObject:array];
                    [array addObject:curTrans];
                }
            }
        }
    }
    else
    {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"walletid ==[c] %@ ", g_appDelegate.currentWallet.id];
        NSMutableArray* categories  = [[Category MR_findAllSortedBy:@"name" ascending:YES withPredicate:predicate] mutableCopy];
        for (int i = 0; i < categories.count; i++) {
            Category* category = [categories objectAtIndex:i];
            NSMutableArray* array = [[NSMutableArray alloc]init];;
            for (int j = 0; j < sortedArray.count; j ++) {
                Transaction* trans = [sortedArray objectAtIndex:j];
                if ([category.id isEqualToString:trans.category.id])
                    [array addObject:trans];
            }
            if (array.count > 0) {
                [transactionDataArray addObject:array];
            }
        }
        
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)theTableView
{
    return transactionDataArray.count;
}

- (NSInteger)tableView:(UITableView *)theTableView numberOfRowsInSection:(NSInteger)section
{
    return [[transactionDataArray objectAtIndex:section] count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 44;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 44;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (transactionDataArray.count - 1 > section && !isSortByCategory) {
        NSMutableArray* dayTransactionArray = [transactionDataArray objectAtIndex:section];
        Transaction* lastTransaction = [dayTransactionArray objectAtIndex:dayTransactionArray.count - 1];
        NSMutableArray* nextArray = [transactionDataArray objectAtIndex:section + 1];
        Transaction* nextTransaction = [nextArray objectAtIndex:nextArray.count - 1];
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        [df setDateFormat:@"MMM"];
        NSString* prevMonth = [df stringFromDate:lastTransaction.date];
        NSString* nextMonth = [df stringFromDate:nextTransaction.date];
        if (![prevMonth isEqualToString:nextMonth]) {
            return 50;
        }
    }
    return 10;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    NSMutableArray* dayTransactionArray = [transactionDataArray objectAtIndex:section];
    static NSString *dateIdentifier = @"datecell";
    static NSString *itemIdentifier = @"transactioncell";
    UITableViewCell *cell;
    if (!isSortByCategory) {
        cell = [tableView dequeueReusableCellWithIdentifier:dateIdentifier];
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:dateIdentifier];
        }
        Transaction* firstTransaction = [dayTransactionArray objectAtIndex:0];
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        
        [df setDateFormat:@"dd"];
        UILabel* dayLbl = [cell viewWithTag:10];
        dayLbl.text = [df stringFromDate:firstTransaction.date];
        
        [df setDateFormat:@"MMM"];
        NSString* month = [df stringFromDate:firstTransaction.date];
        [df setDateFormat:@"yyyy"];
        NSString* year = [df stringFromDate:firstTransaction.date];
        
        UILabel* monthYearLbl = [cell viewWithTag:30];
        monthYearLbl.text = [NSString stringWithFormat:@"%@ %@", month, year];
        
        NSInteger weekdayForTransaction = [[NSCalendar currentCalendar] component:NSCalendarUnitWeekday
                                                                         fromDate:firstTransaction.date];
        //NSDate* today = [NSDate date];
        //NSInteger weekdayForToday = [[NSCalendar currentCalendar] component:NSCalendarUnitWeekday
        //                                                           fromDate:today];
        UILabel* weekDayLabel = [cell viewWithTag:20];
        if ([[NSCalendar currentCalendar] isDate:firstTransaction.date inSameDayAsDate:[NSDate date]])
            weekDayLabel.text = @"Today";
        else
            weekDayLabel.text = [self stringFromWeekDay:weekdayForTransaction];
        // Balance
        UILabel* balanceLbl = [cell viewWithTag:40];
        [balanceLbl setTextColor:[UIColor blackColor]];
        
        float fDayBalance = 0;
        for (int i = 0; i < dayTransactionArray.count; i++) {
            Transaction* transaction = [dayTransactionArray objectAtIndex:i];
            fDayBalance += transaction.amount;
        }
        
        NSNumberFormatter* nf = [[NSNumberFormatter alloc] init] ;
        nf.positiveFormat = @"0.##";
        //balanceLbl.text = [NSString stringWithFormat:@"%@ %@", g_appDelegate.currentWallet.currency.symbol, [nf stringFromNumber: [NSNumber numberWithFloat: fabs(transaction.amount)]]];
        if (fDayBalance > 0.f)
            balanceLbl.text = [NSString stringWithFormat:@"%@ %@", g_appDelegate.currentWallet.currency.symbol, [nf stringFromNumber: [NSNumber numberWithFloat: fabs(fDayBalance)]]];
        else
            balanceLbl.text = [NSString stringWithFormat:@"-%@ %@", g_appDelegate.currentWallet.currency.symbol, [nf stringFromNumber: [NSNumber numberWithFloat: fabs(fDayBalance)]]];
        
        CGRect sepFrame = CGRectMake(0, cell.frame.size.height-1, self.view.frame.size.width, 1);
        UIView* seperatorView = [[UIView alloc] initWithFrame:sepFrame];
        seperatorView.backgroundColor = [UIColor colorWithWhite:224.0/255.0 alpha:1.0];
        [cell addSubview:seperatorView];
    }
    else
    {
        cell = [tableView dequeueReusableCellWithIdentifier:itemIdentifier];
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:dateIdentifier];
        }
        Transaction* firstTransaction = [dayTransactionArray objectAtIndex:0];
        
        UIImageView* categoryImageView = [cell viewWithTag:10];
        categoryImageView.image = [UIImage imageNamed:firstTransaction.category.image];
        
        UILabel* categoryNameLbl = [cell viewWithTag:20];
        categoryNameLbl.text = firstTransaction.category.name;
        
        UILabel* noteLbl = [cell viewWithTag:30];
        noteLbl.text = [NSString stringWithFormat:@"%lu transactions", dayTransactionArray.count];
        
        // Balance
        UILabel* balanceLbl = [cell viewWithTag:40];
        [balanceLbl setTextColor:[UIColor blackColor]];
        float fDayBalance = 0;
        for (int i = 0; i < dayTransactionArray.count; i++) {
            Transaction* transaction = [dayTransactionArray objectAtIndex:i];
            fDayBalance += transaction.amount;
        }
        
        NSNumberFormatter* nf = [[NSNumberFormatter alloc] init] ;
        nf.positiveFormat = @"0.##";
        //balanceLbl.text = [NSString stringWithFormat:@"%@ %@", g_appDelegate.currentWallet.currency.symbol, [nf stringFromNumber: [NSNumber numberWithFloat: fabs(transaction.amount)]]];
        if (fDayBalance > 0.f)
            balanceLbl.text = [NSString stringWithFormat:@"%@ %@", g_appDelegate.currentWallet.currency.symbol, [nf stringFromNumber: [NSNumber numberWithFloat: fabs(fDayBalance)]]];
        else
            balanceLbl.text = [NSString stringWithFormat:@"-%@ %@", g_appDelegate.currentWallet.currency.symbol, [nf stringFromNumber: [NSNumber numberWithFloat: fabs(fDayBalance)]]];
        
        CGRect sepFrame = CGRectMake(0, cell.frame.size.height-1, self.view.frame.size.width, 1);
        UIView* seperatorView = [[UIView alloc] initWithFrame:sepFrame];
        seperatorView.backgroundColor = [UIColor colorWithWhite:224.0/255.0 alpha:1.0];
        [cell addSubview:seperatorView];
    }
    
    return cell;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    //BOOL bIsLastTransaction = NO;
    UIView *footerView;
    if (transactionDataArray.count - 1 > section && !isSortByCategory) {
        
        NSMutableArray* dayTransactionArray = [transactionDataArray objectAtIndex:section];
        Transaction* lastTransaction = [dayTransactionArray objectAtIndex:dayTransactionArray.count - 1];
        NSMutableArray* nextArray = [transactionDataArray objectAtIndex:section + 1];
        Transaction* nextTransaction = [nextArray objectAtIndex:nextArray.count - 1];
        
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        [df setDateFormat:@"MMM"];
        NSString* prevMonth = [df stringFromDate:lastTransaction.date];
        NSString* nextMonth = [df stringFromDate:nextTransaction.date];
        
        if (![prevMonth isEqualToString:nextMonth]) {
            footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, mainTableView.frame.size.width, 50)];
            //[footerView setBackgroundColor:UIColorFromRGB(0x3BAF4A)];
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(mainTableView.frame.size.width / 2 - 75, 10, 150, 30)];
            label.font=[label.font fontWithSize:22];
            label.textAlignment = NSTextAlignmentCenter;
            [df setDateFormat:@"yyyy"];
            NSString* year = [df stringFromDate:nextTransaction.date];
            label.text = [NSString stringWithFormat:@"%@ %@", nextMonth, year];
            [footerView addSubview:label];
            return footerView;
        }
    }
    footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 10)];
    
    return footerView;
}

// the cell will be returned to the tableView
- (UITableViewCell* )tableView:(UITableView* )theTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableArray* dayTransactionArray = [transactionDataArray objectAtIndex:indexPath.section];
    static NSString *dateIdentifier = @"datecell";
    static NSString *itemIdentifier = @"transactioncell";
    UITableViewCell *cell;
    if (!isSortByCategory) {
        cell = [theTableView dequeueReusableCellWithIdentifier:itemIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:itemIdentifier];
        }
        Transaction* transaction = [dayTransactionArray objectAtIndex:indexPath.row];
        UIImageView* categoryImageView = [cell viewWithTag:10];
        categoryImageView.image = [UIImage imageNamed:transaction.category.image];
        
        UILabel* categoryNameLbl = [cell viewWithTag:20];
        categoryNameLbl.text = transaction.category.name;
        
        UILabel* noteLbl = [cell viewWithTag:30];
        noteLbl.text = transaction.notes;
        
        UILabel* balanceLbl = [cell viewWithTag:40];
        if (transaction.amount > 0.f)
            [balanceLbl setTextColor:UIColorFromRGB(0x3BAF4A)];
        else
            [balanceLbl setTextColor:UIColorFromRGB(0xFF2E2E)];
        NSNumberFormatter* nf = [[NSNumberFormatter alloc] init] ;
        nf.positiveFormat = @"0.##";
        balanceLbl.text = [NSString stringWithFormat:@"%@ %@", g_appDelegate.currentWallet.currency.symbol, [nf stringFromNumber: [NSNumber numberWithFloat: fabs(transaction.amount)]]];
    }
    else
    {
        cell = [theTableView dequeueReusableCellWithIdentifier:dateIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:itemIdentifier];
        }
        Transaction* transaction = [dayTransactionArray objectAtIndex:indexPath.row];
        
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        
        [df setDateFormat:@"dd"];
        UILabel* dayLbl = [cell viewWithTag:10];
        dayLbl.text = [df stringFromDate:transaction.date];
        
        [df setDateFormat:@"MMM"];
        NSString* month = [df stringFromDate:transaction.date];
        [df setDateFormat:@"yyyy"];
        NSString* year = [df stringFromDate:transaction.date];
        
        UILabel* monthYearLbl = [cell viewWithTag:30];
        monthYearLbl.text = [NSString stringWithFormat:@"%@ %@", month, year];
        
        NSInteger weekdayForTransaction = [[NSCalendar currentCalendar] component:NSCalendarUnitWeekday
                                                                         fromDate:transaction.date];
        //NSDate* today = [NSDate date];
        //NSInteger weekdayForToday = [[NSCalendar currentCalendar] component:NSCalendarUnitWeekday
        //                                                           fromDate:today];
        UILabel* weekDayLabel = [cell viewWithTag:20];
        if ([[NSCalendar currentCalendar] isDate:transaction.date inSameDayAsDate:[NSDate date]])
            weekDayLabel.text = @"Today";
        else
            weekDayLabel.text = [self stringFromWeekDay:weekdayForTransaction];
        
        // balance
        UILabel* balanceLbl = [cell viewWithTag:40];
        if (transaction.amount > 0.f)
            [balanceLbl setTextColor:UIColorFromRGB(0x3BAF4A)];
        else
            [balanceLbl setTextColor:UIColorFromRGB(0xFF2E2E)];
        NSNumberFormatter* nf = [[NSNumberFormatter alloc] init] ;
        nf.positiveFormat = @"0.##";
        balanceLbl.text = [NSString stringWithFormat:@"%@ %@", g_appDelegate.currentWallet.currency.symbol, [nf stringFromNumber: [NSNumber numberWithFloat: fabs(transaction.amount)]]];
    }
    
    return cell;
}

#pragma mark - UITableViewDelegate
// when user tap the row, what action you want to perform
- (void)tableView:(UITableView* )theTableView didSelectRowAtIndexPath:(NSIndexPath* )indexPath
{
    NSMutableArray* dayTransactionArray = [transactionDataArray objectAtIndex:indexPath.section];
    Transaction* transaction = [dayTransactionArray objectAtIndex:indexPath.row];
    EditTransactionVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"EditTransactionVC"];
    vc.transactionToEdit = transaction;
    [self.navigationController pushViewController:vc animated:YES];
    
    NSLog(@"selected %ld row", (long)indexPath.row);
}

#pragma mark - Button Callback
- (IBAction)onClickChangeWallet:(id)sender {
    SelectWalletVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"SelectWalletVC"];
    vc.prevVC = @"TransactionVC";
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)onClickAddTransaction:(id)sender {
    UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"AddTransactionVC"];
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)onClickSideMenu:(id)sender {
    
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        
        // Cancel button tappped do nothing.
        
    }]];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Jump to today" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [mainTableView setContentOffset:CGPointZero animated:YES];
    }]];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Select time range" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {

        [self tapSelectTimeRange];
    }]];
    if (!isSortByCategory) {
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Sort by category" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            isSortByCategory = YES;
            [self updateTimeRange];
        }]];
    }else
        [actionSheet addAction:[UIAlertAction actionWithTitle:@"Sort by transaction" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            isSortByCategory = NO;
            [self updateTimeRange];
        }]];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Transfer money" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"TransferMoneyVC"];
        [self.navigationController pushViewController:vc animated:YES];
        
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Adjust balance" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"AdjustBalanceVC"];
        [self.navigationController pushViewController:vc animated:YES];
        
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Search for transaction" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"SearchTransactionTableVC"];
        [self.navigationController pushViewController:vc animated:YES];
        
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Recurring payments" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        UIViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"RecurringTransactionVC"];
        [self.navigationController pushViewController:vc animated:YES];
        
    }]];
    [self presentViewController:actionSheet animated:YES completion:nil];

}

- (void) tapSelectTimeRange
{
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        
        // Cancel button tappped do nothing.
        
    }]];
    
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"All" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        startDate = nil;
        endDate = nil;
        [self updateTimeRange];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Week" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
        NSCalendar *cal = [NSCalendar currentCalendar];
        NSDate *now = [NSDate date];
        NSDate *startOfTheWeek;
        //NSDate *endOfWeek;
        NSTimeInterval interval;
        [cal rangeOfUnit:NSCalendarUnitWeekOfMonth
               startDate:&startOfTheWeek
                interval:&interval
                 forDate:now];
        //startOfWeek holds now the first day of the week, according to locale (monday vs. sunday)
        
        //endOfWeek = [startOfTheWeek dateByAddingTimeInterval:interval-1];
        startDate = startOfTheWeek;
        endDate = now;
        [self updateTimeRange];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Month" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSDateComponents *components = [[NSCalendar currentCalendar] components:(NSCalendarUnitEra | NSYearCalendarUnit | NSMonthCalendarUnit) fromDate:[NSDate date]];
        components.day = 1;
        
        startDate = [[NSCalendar currentCalendar] dateFromComponents:components];
        endDate = [NSDate date];
        [self updateTimeRange];
    }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:@"Custom" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        SetTimeRangeVC *VC = [self.storyboard instantiateViewControllerWithIdentifier:@"SetTimeRangeVC"];
        VC.delegate = self;
        [self.navigationController pushViewController:VC animated:YES];
    }]];
    [self presentViewController:actionSheet animated:YES completion:nil];
}

- (void) updateTimeRange
{
    [self setBalances];
    [self fetchTransactionData];
    [mainTableView reloadData];
    [self updateTimeLabel];
}

- (void) updateTimeLabel
{
    if (startDate ==  nil && endDate == nil) {
        timeRangeLbl.text = @"All";
    }
    else
    {
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        [df setDateFormat:@"dd"];
        NSString* dayForStart = [df stringFromDate:startDate];
        [df setDateFormat:@"MM"];
        NSString* monthForStart = [df stringFromDate:startDate];
        [df setDateFormat:@"yyyy"];
        NSString* yearForStart = [df stringFromDate:startDate];
        
        
        [df setDateFormat:@"dd"];
        NSString* dayForEnd = [df stringFromDate:endDate];
        [df setDateFormat:@"MM"];
        NSString* monthForEnd = [df stringFromDate:endDate];
        [df setDateFormat:@"yyyy"];
        NSString* yearForEnd = [df stringFromDate:endDate];
        
        timeRangeLbl.text = [NSString stringWithFormat:@"%@/%@/%@ - %@/%@/%@", dayForStart, monthForStart, yearForStart, dayForEnd, monthForEnd, yearForEnd];
    }
}

- (void) timeRangeUpdated:(NSDate *)startDateNew endDate:(NSDate *)endDateNew
{
    startDate = startDateNew;
    endDate = endDateNew;
    [self updateTimeRange];
}

- (NSString *) stringFromWeekDay:(NSInteger) weekDay
{
    switch (weekDay)
    {
        case 1:
            return @"Sunday";
            break;
        case 2:
            return @"Monday";
            break;
        case 3:
            return @"Tuesday";
            break;
        case 4:
            return @"Wednesday";
            break;
        case 5:
            return @"Thursday";
            break;
        case 6:
            return @"Friday";
            break;
        case 7:
            return @"Saturday";
            break;
        default:
            return @"Sunday";
            break;
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
