//
//  MyTabVC.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/5/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTabVC : UITabBarController

@end
