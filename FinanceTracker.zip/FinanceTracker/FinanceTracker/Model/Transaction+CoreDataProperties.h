//
//  Transaction+CoreDataProperties.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/26/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import "Transaction+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Transaction (CoreDataProperties)

+ (NSFetchRequest<Transaction *> *)fetchRequest;

@property (nonatomic) float amount;
@property (nullable, nonatomic, copy) NSDate *date;
@property (nullable, nonatomic, copy) NSString *event;
@property (nullable, nonatomic, copy) NSString *notes;
@property (nullable, nonatomic, copy) NSString *walletid;
@property (nullable, nonatomic, retain) Category *category;

@end

NS_ASSUME_NONNULL_END
