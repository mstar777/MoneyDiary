//
//  Category+CoreDataProperties.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/16/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import "Category+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Category (CoreDataProperties)

+ (NSFetchRequest<Category *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *name;
@property (nullable, nonatomic, copy) NSString *image;
@property (nonatomic) int16_t type;
@property (nullable, nonatomic, copy) NSString *id;
@property (nullable, nonatomic, copy) NSString *parentid;
@property (nullable, nonatomic, copy) NSString *walletid;

@end

NS_ASSUME_NONNULL_END
