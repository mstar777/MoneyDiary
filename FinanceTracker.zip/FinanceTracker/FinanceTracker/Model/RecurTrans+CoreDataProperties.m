//
//  RecurTrans+CoreDataProperties.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 4/10/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import "RecurTrans+CoreDataProperties.h"

@implementation RecurTrans (CoreDataProperties)

+ (NSFetchRequest<RecurTrans *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"RecurTrans"];
}

@dynamic amount;
@dynamic frequency;
@dynamic interval;
@dynamic notes;
@dynamic startDate;
@dynamic walletid;
@dynamic status;
@dynamic category;

@end
