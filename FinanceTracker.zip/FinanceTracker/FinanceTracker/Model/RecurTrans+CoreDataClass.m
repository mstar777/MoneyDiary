//
//  RecurTrans+CoreDataClass.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 4/9/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import "RecurTrans+CoreDataClass.h"

@implementation RecurTrans

@end
