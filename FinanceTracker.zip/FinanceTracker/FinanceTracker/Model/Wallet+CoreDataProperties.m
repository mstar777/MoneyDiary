//
//  Wallet+CoreDataProperties.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/21/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import "Wallet+CoreDataProperties.h"

@implementation Wallet (CoreDataProperties)

+ (NSFetchRequest<Wallet *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Wallet"];
}

@dynamic balance;
@dynamic id;
@dynamic image;
@dynamic name;
@dynamic userid;
@dynamic currency;

@end
