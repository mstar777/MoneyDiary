//
//  Wallet+CoreDataClass.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/8/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import "Wallet+CoreDataClass.h"

@implementation Wallet

@end
