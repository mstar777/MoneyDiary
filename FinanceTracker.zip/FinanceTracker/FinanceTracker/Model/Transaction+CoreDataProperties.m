//
//  Transaction+CoreDataProperties.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/26/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import "Transaction+CoreDataProperties.h"

@implementation Transaction (CoreDataProperties)

+ (NSFetchRequest<Transaction *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Transaction"];
}

@dynamic amount;
@dynamic date;
@dynamic event;
@dynamic notes;
@dynamic walletid;
@dynamic category;

@end
