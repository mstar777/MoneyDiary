//
//  User+CoreDataProperties.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/19/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import "User+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface User (CoreDataProperties)

+ (NSFetchRequest<User *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *email;
@property (nullable, nonatomic, copy) NSString *id;
@property (nullable, nonatomic, copy) NSString *name;
@property (nullable, nonatomic, copy) NSString *pass;
@property (nullable, nonatomic, copy) NSString *activewalletid;

@end

NS_ASSUME_NONNULL_END
