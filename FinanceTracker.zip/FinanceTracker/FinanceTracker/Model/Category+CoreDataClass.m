//
//  Category+CoreDataClass.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/16/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import "Category+CoreDataClass.h"

@implementation Category

@end
