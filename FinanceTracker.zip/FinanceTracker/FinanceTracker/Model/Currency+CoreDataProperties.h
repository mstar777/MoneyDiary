//
//  Currency+CoreDataProperties.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/14/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import "Currency+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Currency (CoreDataProperties)

+ (NSFetchRequest<Currency *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *name;
@property (nullable, nonatomic, copy) NSString *symbol;

@end

NS_ASSUME_NONNULL_END
