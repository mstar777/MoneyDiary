//
//  User+CoreDataProperties.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/19/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import "User+CoreDataProperties.h"

@implementation User (CoreDataProperties)

+ (NSFetchRequest<User *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"User"];
}

@dynamic email;
@dynamic id;
@dynamic name;
@dynamic pass;
@dynamic activewalletid;

@end
