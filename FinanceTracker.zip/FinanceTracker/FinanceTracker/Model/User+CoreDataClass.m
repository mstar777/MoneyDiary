//
//  User+CoreDataClass.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/8/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import "User+CoreDataClass.h"

@implementation User

@end
