//
//  Category+CoreDataClass.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/16/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface Category : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Category+CoreDataProperties.h"
