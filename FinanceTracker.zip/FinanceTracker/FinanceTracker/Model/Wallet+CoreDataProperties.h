//
//  Wallet+CoreDataProperties.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/21/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import "Wallet+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Wallet (CoreDataProperties)

+ (NSFetchRequest<Wallet *> *)fetchRequest;

@property (nonatomic) float balance;
@property (nullable, nonatomic, copy) NSString *id;
@property (nullable, nonatomic, copy) NSString *image;
@property (nullable, nonatomic, copy) NSString *name;
@property (nullable, nonatomic, copy) NSString *userid;
@property (nullable, nonatomic, retain) Currency *currency;

@end

NS_ASSUME_NONNULL_END
