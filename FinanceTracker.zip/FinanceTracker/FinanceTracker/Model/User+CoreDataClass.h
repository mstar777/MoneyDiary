//
//  User+CoreDataClass.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/8/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Wallet;

NS_ASSUME_NONNULL_BEGIN

@interface User : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "User+CoreDataProperties.h"
