//
//  RecurTrans+CoreDataClass.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 4/9/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Category;

NS_ASSUME_NONNULL_BEGIN

@interface RecurTrans : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "RecurTrans+CoreDataProperties.h"
