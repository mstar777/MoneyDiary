//
//  RecurTrans+CoreDataProperties.h
//  FinanceTracker
//
//  Created by Leslie Reynoso on 4/10/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import "RecurTrans+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface RecurTrans (CoreDataProperties)

+ (NSFetchRequest<RecurTrans *> *)fetchRequest;

@property (nonatomic) float amount;
@property (nonatomic) int16_t frequency;
@property (nonatomic) int16_t interval;
@property (nullable, nonatomic, copy) NSString *notes;
@property (nullable, nonatomic, copy) NSDate *startDate;
@property (nullable, nonatomic, copy) NSString *walletid;
@property (nonatomic) int16_t status;
@property (nullable, nonatomic, retain) Category *category;

@end

NS_ASSUME_NONNULL_END
