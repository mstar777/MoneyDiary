//
//  Currency+CoreDataProperties.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/14/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//
//

#import "Currency+CoreDataProperties.h"

@implementation Currency (CoreDataProperties)

+ (NSFetchRequest<Currency *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Currency"];
}

@dynamic name;
@dynamic symbol;

@end
