//
//  AppDelegate.m
//  FinanceTracker
//
//  Created by Leslie Reynoso on 3/1/18.
//  Copyright © 2018 Leslie Reynoso. All rights reserved.
//

#import "AppDelegate.h"
#import "Constant.h"

AppDelegate *g_appDelegate;

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    g_appDelegate = self; // extern variable. used to call appdelegate on other place
    [MagicalRecord setupCoreDataStackWithStoreNamed:@"testWalletModel"]; // setup core data
    
    [self loadUserAccountInfo]; // load user account info
    
    if (![[NSUserDefaults standardUserDefaults] objectForKey:@"IsFirstLogin"]) { // when user login first time
        /*
        //Test User
        User* user = [User MR_createEntity];
        user.name = @"test";
        user.email = @"test@test.com";
        user.pass = @"123";
        user.id = [[NSUUID UUID] UUIDString];
        
        self.currentUser = user;
        //[self setUserAccountInfo:user.id];
        */
        
        //***** Currency *****//
        // add template currency
        NSString *filePath = [[NSBundle mainBundle] pathForResource:@"currency_new" ofType:@"plist"];
        NSDictionary *resultDictionary = [NSDictionary dictionaryWithContentsOfFile:filePath];
        NSDictionary* countries = [resultDictionary objectForKey:@"symbols"];
        for (NSString *key in countries) {
            id value = countries[key];
            NSLog(@"Value: %@ for key: %@", value, key);
            NSString *currencyCode = key;
            NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:currencyCode];
            NSString *currencySymbol = [NSString stringWithFormat:@"%@",[locale displayNameForKey:NSLocaleCurrencySymbol value:currencyCode]];
            NSString* currencyName = [NSString stringWithFormat:@"%@ (%@)", value, key];
            
            Currency* currency = [Currency MR_createEntity]; // this is core data code
            currency.name = currencyName;
            currency.symbol = currencySymbol;
        }
        //***** Currency *****//
        
        
        [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:nil]; // save core data entity
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"IsFirstLogin"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    
    return YES;
}

+ (void)createCategory:(NSString *) walletId // add template categories to wallet
{
    //***** Category *****//
    NSString* filePath = [[NSBundle mainBundle] pathForResource:@"category" ofType:@"plist"];
    NSMutableArray* categories = [NSMutableArray arrayWithContentsOfFile:filePath];
    for (int i = 0; i < categories.count; i++) {
        NSDictionary *category = [categories objectAtIndex:i] ;
        
        Category* newCategory = [Category MR_createEntity];
        newCategory.id = [category objectForKey:@"id"];
        newCategory.name = [category objectForKey:@"name"];
        newCategory.image = [category objectForKey:@"image"];
        newCategory.type = [[category objectForKey:@"type"] intValue];
        newCategory.parentid = [category objectForKey:@"parentid"];
        newCategory.walletid = walletId;
    }
    //***** Category *****//
}

+ (void)showMessage:(NSString *)message // this is for display alert popup view
{
    NSString *appName = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleDisplayName"];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:appName
                                                    message:message
                                                   delegate:nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
}

- (void)loadUserAccountInfo
{
    NSString* userId = [[NSUserDefaults standardUserDefaults] objectForKey:@"userId"];
    //NSString* walletId = [[NSUserDefaults standardUserDefaults] objectForKey:@"walletId"];
    
    if(userId == nil)
        userId = @"";
    
    //if(walletId == nil)
    //    walletId = @"";
    
    self.currentUser = [User MR_findFirstByAttribute:@"id" withValue:userId];
    if (self.currentUser != nil)
        self.currentWallet = [Wallet MR_findFirstByAttribute:@"id" withValue:self.currentUser.activewalletid];
}

- (void)setUserAccountInfo:(NSString *)userId
{
    self.currentUser = [User MR_findFirstByAttribute:@"id" withValue:userId];
    
    [[NSUserDefaults standardUserDefaults] setObject:userId forKey:@"userId"];
    //[[NSUserDefaults standardUserDefaults] setObject:walletId forKey:@"walletId"];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)removeUserAccountInfo
{
    self.currentUser = nil;
    self.currentWallet = nil;
    
    [[NSUserDefaults standardUserDefaults] setObject:@"" forKey:@"userId"];
    //[[NSUserDefaults standardUserDefaults] setObject:@"" forKey:@"walletId"];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
    
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
